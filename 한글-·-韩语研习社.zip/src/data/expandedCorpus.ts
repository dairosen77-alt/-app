import { VocabItem } from './koreanData';

export interface DramaSentenceItem {
  id: string;
  drama: string;
  korean: string;
  roman: string;
  chinese: string;
  category: string;
}

const CORE_ROOTS: Array<{
  kr: string;
  roman: string;
  cn: string;
  pos: string;
  cat: VocabItem['category'];
}> = [
  { kr: '사랑', roman: 'sarang', cn: '爱', pos: '名词', cat: '情感表达' },
  { kr: '행복', roman: 'haengbok', cn: '幸福', pos: '名词', cat: '情感表达' },
  { kr: '기억', roman: 'gieok', cn: '记忆', pos: '名词', cat: '韩剧高频' },
  { kr: '약속', roman: 'yaksok', cn: '约定', pos: '名词', cat: '韩剧高频' },
  { kr: '운명', roman: 'unmyeong', cn: '命运', pos: '名词', cat: '韩剧高频' },
  { kr: '비밀', roman: 'bimil', cn: '秘密', pos: '名词', cat: '韩剧高频' },
  { kr: '오해', roman: 'ohae', cn: '误会', pos: '名词', cat: '韩剧高频' },
  { kr: '진심', roman: 'jinsim', cn: '真心', pos: '名词', cat: '韩剧高频' },
  { kr: '마음', roman: 'maeum', cn: '心意', pos: '名词', cat: '情感表达' },
  { kr: '눈물', roman: 'nunmul', cn: '眼泪', pos: '名词', cat: '韩剧高频' },
  { kr: '미소', roman: 'miso', cn: '微笑', pos: '名词', cat: '情感表达' },
  { kr: '시간', roman: 'sigan', cn: '时间', pos: '名词', cat: '日常问候' },
  { kr: '오늘', roman: 'oneul', cn: '今天', pos: '名词', cat: '日常问候' },
  { kr: '내일', roman: 'naeil', cn: '明天', pos: '名词', cat: '日常问候' },
  { kr: '어제', roman: 'eoje', cn: '昨天', pos: '名词', cat: '日常问候' },
  { kr: '친구', roman: 'chingu', cn: '朋友', pos: '名词', cat: '日常问候' },
  { kr: '가족', roman: 'gajok', cn: '家人', pos: '名词', cat: '日常问候' },
  { kr: '선물', roman: 'seonmul', cn: '礼物', pos: '名词', cat: '购物数字' },
  { kr: '커피', roman: 'keopi', cn: '咖啡', pos: '名词', cat: '咖啡与美食' },
  { kr: '음식', roman: 'eumsik', cn: '食物', pos: '名词', cat: '咖啡与美食' },
  { kr: '식당', roman: 'sikdang', cn: '餐厅', pos: '名词', cat: '咖啡与美食' },
  { kr: '지하철', roman: 'jihacheol', cn: '地铁', pos: '名词', cat: '交通出行' },
  { kr: '버스', roman: 'beoseu', cn: '公交车', pos: '名词', cat: '交通出行' },
  { kr: '비행기', roman: 'bihaenggi', cn: '飞机', pos: '名词', cat: '交通出行' },
  { kr: '여행', roman: 'yeohaeng', cn: '旅行', pos: '名词', cat: '交通出行' },
  { kr: '사진', roman: 'sajin', cn: '照片', pos: '名词', cat: '日常问候' },
  { kr: '음악', roman: 'eumak', cn: '音乐', pos: '名词', cat: '情感表达' },
  { kr: '영화', roman: 'yeonghwa', cn: '电影', pos: '名词', cat: '韩剧高频' },
  { kr: '드라마', roman: 'deurama', cn: '电视剧', pos: '名词', cat: '韩剧高频' },
  { kr: '날씨', roman: 'nalssi', cn: '天气', pos: '名词', cat: '日常问候' },
  { kr: '하늘', roman: 'haneul', cn: '天空', pos: '名词', cat: '情感表达' },
  { kr: '바다', roman: 'bada', cn: '大海', pos: '名词', cat: '交通出行' },
  { kr: '산책', roman: 'sanchaek', cn: '散步', pos: '名词', cat: '日常问候' },
  { kr: '운동', roman: 'undong', cn: '运动', pos: '名词', cat: '日常问候' },
  { kr: '공부', roman: 'gongbu', cn: '学习', pos: '名词', cat: '日常问候' },
  { kr: '회사', roman: 'hoesa', cn: '公司', pos: '名词', cat: '日常问候' },
  { kr: '학교', roman: 'hakgyo', cn: '学校', pos: '名词', cat: '日常问候' },
  { kr: '병원', roman: 'byeongwon', cn: '医院', pos: '名词', cat: '交通出行' },
  { kr: '약국', roman: 'yakguk', cn: '药店', pos: '名词', cat: '交通出行' },
  { kr: '편의점', roman: 'pyeonuijeom', cn: '便利店', pos: '名词', cat: '购物数字' },
  { kr: '백화점', roman: 'baekhwajeom', cn: '百货商店', pos: '名词', cat: '购物数字' },
  { kr: '가격', roman: 'gagyeok', cn: '价格', pos: '名词', cat: '购物数字' },
  { kr: '할인', roman: 'harin', cn: '折扣', pos: '名词', cat: '购物数字' },
  { kr: '계산', roman: 'gyesan', cn: '结账', pos: '名词', cat: '购物数字' },
  { kr: '주문', roman: 'jumun', cn: '点单', pos: '名词', cat: '咖啡与美食' },
  { kr: '포장', roman: 'pojang', cn: '打包', pos: '名词', cat: '咖啡与美食' },
  { kr: '예약', roman: 'yeyak', cn: '预约', pos: '名词', cat: '咖啡与美食' },
  { kr: '도착', roman: 'dochak', cn: '到达', pos: '名词', cat: '交通出行' },
  { kr: '출발', roman: 'chulbal', cn: '出发', pos: '名词', cat: '交通出行' },
  { kr: '준비', roman: 'junbi', cn: '准备', pos: '名词', cat: '日常问候' },
];

const VERB_STEMS: Array<{
  stem: string;
  polite: string;
  past: string;
  future: string;
  romanBase: string;
  cn: string;
  cat: VocabItem['category'];
}> = [
  { stem: '가다', polite: '가요', past: '갔어요', future: '갈 거예요', romanBase: 'ga', cn: '去', cat: '交通出行' },
  { stem: '오다', polite: '와요', past: '왔어요', future: '올 거예요', romanBase: 'o', cn: '来', cat: '交通出行' },
  { stem: '먹다', polite: '먹어요', past: '먹었어요', future: '먹을 거예요', romanBase: 'meok', cn: '吃', cat: '咖啡与美食' },
  { stem: '마시다', polite: '마셔요', past: '마셨어요', future: '마실 거예요', romanBase: 'masi', cn: '喝', cat: '咖啡与美食' },
  { stem: '보다', polite: '봐요', past: '봤어요', future: '볼 거예요', romanBase: 'bo', cn: '看', cat: '韩剧高频' },
  { stem: '듣다', polite: '들어요', past: '들었어요', future: '들을 거예요', romanBase: 'deut', cn: '听', cat: '日常问候' },
  { stem: '말하다', polite: '말해요', past: '말했어요', future: '말할 거예요', romanBase: 'malha', cn: '说', cat: '日常问候' },
  { stem: '읽다', polite: '읽어요', past: '읽었어요', future: '읽을 거예요', romanBase: 'ik', cn: '读', cat: '日常问候' },
  { stem: '쓰다', polite: '써요', past: '썼어요', future: '쓸 거예요', romanBase: 'sseu', cn: '写', cat: '日常问候' },
  { stem: '사다', polite: '사요', past: '샀어요', future: '살 거예요', romanBase: 'sa', cn: '买', cat: '购物数字' },
  { stem: '주다', polite: '줘요', past: '줬어요', future: '줄 거예요', romanBase: 'ju', cn: '给', cat: '日常问候' },
  { stem: '받다', polite: '받아요', past: '받았어요', future: '받을 거예요', romanBase: 'bat', cn: '收/接', cat: '日常问候' },
  { stem: '만나다', polite: '만나요', past: '만났어요', future: '만날 거예요', romanBase: 'manna', cn: '见面', cat: '韩剧高频' },
  { stem: '기다리다', polite: '기다려요', past: '기다렸어요', future: '기다릴 거예요', romanBase: 'gidari', cn: '等待', cat: '韩剧高频' },
  { stem: '찾다', polite: '찾아요', past: '찾았어요', future: '찾을 거예요', romanBase: 'chat', cn: '寻找', cat: '韩剧高频' },
  { stem: '잊다', polite: '잊어요', past: '잊었어요', future: '잊을 거예요', romanBase: 'it', cn: '忘记', cat: '韩剧高频' },
  { stem: '믿다', polite: '믿어요', past: '믿었어요', future: '믿을 거예요', romanBase: 'mit', cn: '相信', cat: '情感表达' },
  { stem: '웃다', polite: '웃어요', past: '웃었어요', future: '웃을 거예요', romanBase: 'ut', cn: '笑', cat: '情感表达' },
  { stem: '울다', polite: '울어요', past: '울었어요', future: '울 거예요', romanBase: 'ul', cn: '哭', cat: '情感表达' },
  { stem: '걷다', polite: '걸어요', past: '걸었어요', future: '걸을 거예요', romanBase: 'geot', cn: '走', cat: '交通出行' },
  { stem: '뛰다', polite: '뛰어요', past: '뛰었어요', future: '뛸 거예요', romanBase: 'ttwi', cn: '跑', cat: '交通出行' },
  { stem: '자다', polite: '자요', past: '잤어요', future: '잘 거예요', romanBase: 'ja', cn: '睡觉', cat: '日常问候' },
  { stem: '일어나다', polite: '일어나요', past: '일어났어요', future: '일어날 거예요', romanBase: 'ireona', cn: '起床', cat: '日常问候' },
  { stem: '쉬다', polite: '쉬어요', past: '쉬었어요', future: '쉴 거예요', romanBase: 'swi', cn: '休息', cat: '日常问候' },
  { stem: '일하다', polite: '일해요', past: '일했어요', future: '일할 거예요', romanBase: 'ilha', cn: '工作', cat: '日常问候' },
  { stem: '공부하다', polite: '공부해요', past: '공부했어요', future: '공부할 거예요', romanBase: 'gongbuha', cn: '学习', cat: '日常问候' },
  { stem: '사랑하다', polite: '사랑해요', past: '사랑했어요', future: '사랑할 거예요', romanBase: 'sarangha', cn: '爱', cat: '情感表达' },
  { stem: '좋아하다', polite: '좋아해요', past: '좋아했어요', future: '좋아할 거예요', romanBase: 'joaha', cn: '喜欢', cat: '情感表达' },
  { stem: '싫어하다', polite: '싫어해요', past: '싫어했어요', future: '싫어할 거예요', romanBase: 'sireoha', cn: '讨厌', cat: '情感表达' },
  { stem: '걱정하다', polite: '걱정해요', past: '걱정했어요', future: '걱정할 거예요', romanBase: 'geokjeongha', cn: '担心', cat: '情感表达' },
  { stem: '약속하다', polite: '약속해요', past: '약속했어요', future: '약속할 거예요', romanBase: 'yaksokha', cn: '约定', cat: '韩剧高频' },
  { stem: '고백하다', polite: '고백해요', past: '고백했어요', future: '고백할 거예요', romanBase: 'gobaekha', cn: '告白', cat: '韩剧高频' },
  { stem: '이별하다', polite: '이별해요', past: '이별했어요', future: '이별할 거예요', romanBase: 'ibyeolha', cn: '离别', cat: '韩剧高频' },
  { stem: '용서하다', polite: '용서해요', past: '용서했어요', future: '용서할 거예요', romanBase: 'yongseoha', cn: '原谅', cat: '韩剧高频' },
  { stem: '포기하다', polite: '포기해요', past: '포기했어요', future: '포기할 거예요', romanBase: 'pogiha', cn: '放弃', cat: '韩剧高频' },
  { stem: '응원하다', polite: '응원해요', past: '응원했어요', future: '응원할 거예요', romanBase: 'eungwonha', cn: '应援/加油', cat: '情感表达' },
  { stem: '축하하다', polite: '축하해요', past: '축하했어요', future: '축하할 거예요', romanBase: 'chukhaha', cn: '祝贺', cat: '日常问候' },
  { stem: '감사하다', polite: '감사해요', past: '감사했어요', future: '감사할 거예요', romanBase: 'gamsaha', cn: '感谢', cat: '日常问候' },
  { stem: '사과하다', polite: '사과해요', past: '사과했어요', future: '사과할 거예요', romanBase: 'sagwaha', cn: '道歉', cat: '日常问候' },
  { stem: '결정하다', polite: '결정해요', past: '결정했어요', future: '결정할 거예요', romanBase: 'gyeoljeongha', cn: '决定', cat: '日常问候' },
];

const ADJ_STEMS: Array<{
  stem: string;
  polite: string;
  romanBase: string;
  cn: string;
  cat: VocabItem['category'];
}> = [
  { stem: '좋다', polite: '좋아요', romanBase: 'jo', cn: '好', cat: '情感表达' },
  { stem: '나쁘다', polite: '나빠요', romanBase: 'nappeu', cn: '坏', cat: '情感表达' },
  { stem: '크다', polite: '커요', romanBase: 'keu', cn: '大', cat: '购物数字' },
  { stem: '작다', polite: '작아요', romanBase: 'jak', cn: '小', cat: '购物数字' },
  { stem: '많다', polite: '많아요', romanBase: 'man', cn: '多', cat: '购物数字' },
  { stem: '적다', polite: '적어요', romanBase: 'jeok', cn: '少', cat: '购物数字' },
  { stem: '비싸다', polite: '비싸요', romanBase: 'bissa', cn: '贵', cat: '购物数字' },
  { stem: '싸다', polite: '싸요', romanBase: 'ssa', cn: '便宜', cat: '购物数字' },
  { stem: '맛있다', polite: '맛있어요', romanBase: 'masit', cn: '好吃', cat: '咖啡与美食' },
  { stem: '맛없다', polite: '맛없어요', romanBase: 'madeop', cn: '难吃', cat: '咖啡与美食' },
  { stem: '예쁘다', polite: '예뻐요', romanBase: 'yeppeu', cn: '漂亮', cat: '情感表达' },
  { stem: '멋있다', polite: '멋있어요', romanBase: 'meosit', cn: '帅气', cat: '韩剧高频' },
  { stem: '귀엽다', polite: '귀여워요', romanBase: 'gwiyeop', cn: '可爱', cat: '情感表达' },
  { stem: '슬프다', polite: '슬퍼요', romanBase: 'seulpeu', cn: '悲伤', cat: '韩剧高频' },
  { stem: '기쁘다', polite: '기뻐요', romanBase: 'gippeu', cn: '高兴', cat: '情感表达' },
  { stem: '아프다', polite: '아파요', romanBase: 'apeu', cn: '疼/生病', cat: '日常问候' },
  { stem: '바쁘다', polite: '바빠요', romanBase: 'bappeu', cn: '忙碌', cat: '日常问候' },
  { stem: '피곤하다', polite: '피곤해요', romanBase: 'pigonha', cn: '累', cat: '日常问候' },
  { stem: '심심하다', polite: '심심해요', romanBase: 'simsimha', cn: '无聊', cat: '日常问候' },
  { stem: '따뜻하다', polite: '따뜻해요', romanBase: 'ttatteutha', cn: '温暖', cat: '咖啡与美食' },
  { stem: '시원하다', polite: '시원해요', romanBase: 'siwonha', cn: '凉爽', cat: '咖啡与美食' },
  { stem: '춥다', polite: '추워요', romanBase: 'chup', cn: '冷', cat: '日常问候' },
  { stem: '덥다', polite: '더워요', romanBase: 'deop', cn: '热', cat: '日常问候' },
  { stem: '어렵다', polite: '어려워요', romanBase: 'eoryeop', cn: '难', cat: '日常问候' },
  { stem: '쉽다', polite: '쉬워요', romanBase: 'swip', cn: '容易', cat: '日常问候' },
  { stem: '중요하다', polite: '중요해요', romanBase: 'jungyoha', cn: '重要', cat: '韩剧高频' },
  { stem: '위험하다', polite: '위험해요', romanBase: 'wiheomha', cn: '危险', cat: '韩剧高频' },
  { stem: '안전하다', polite: '안전해요', romanBase: 'anjeonha', cn: '安全', cat: '交通出行' },
  { stem: '편하다', polite: '편해요', romanBase: 'pyeonha', cn: '舒服/方便', cat: '日常问候' },
  { stem: '불편하다', polite: '불편해요', romanBase: 'bulpyeonha', cn: '不方便', cat: '日常问候' },
];

const DRAMA_TITLES = [
  '眼泪女王',
  '背着善宰跑',
  '鬼怪',
  '黑暗荣耀',
  '爱的迫降',
  '请回答1988',
  '太阳的后裔',
  '二十五，二十一',
  '梨泰院Class',
  '机智的医生生活',
];

export function generateExpandedVocabulary(baseList: VocabItem[], targetCount = 2000): VocabItem[] {
  const result: VocabItem[] = [...baseList];
  const seen = new Set<string>(baseList.map((v) => v.korean));

  const addEntry = (item: Omit<VocabItem, 'id'>) => {
    if (result.length >= targetCount) return;
    if (seen.has(item.korean)) return;
    seen.add(item.korean);
    result.push({
      ...item,
      id: `v_gen_${result.length + 1}`,
    });
  };

  // 1. Add all root nouns + common particle combinations
  const nounSuffixes = [
    { kr: '', ro: '', cn: '' },
    { kr: '이/가', ro: 'i/ga', cn: '（主格）' },
    { kr: '을/를', ro: 'eul/reul', cn: '（宾格）' },
    { kr: '도', ro: 'do', cn: '也…' },
    { kr: '만', ro: 'man', cn: '只…' },
    { kr: '부터', ro: 'buteo', cn: '从…开始' },
    { kr: '까지', ro: 'kkaji', cn: '到…为止' },
    { kr: '처럼', ro: 'cheoreom', cn: '像…一样' },
  ];

  for (const root of CORE_ROOTS) {
    for (const suf of nounSuffixes) {
      if (result.length >= targetCount) break;
      const kr = suf.kr ? `${root.kr}${suf.kr.split('/')[0]}` : root.kr;
      const ro = suf.ro ? `${root.roman}${suf.ro.split('/')[0]}` : root.roman;
      addEntry({
        korean: kr,
        roman: ro,
        chinese: `${root.cn}${suf.cn}`,
        pos: suf.kr ? '名词短语' : root.pos,
        category: root.cat,
        exampleKr: `우리는 ${root.kr}에 대해 이야기했어요.`,
        exampleCn: `我们谈论了关于${root.cn}的事情。`,
      });
    }
  }

  // 2. Add verb conjugations (stem, polite, past, future, desire, negative, imperative, progressive)
  const verbForms = [
    { key: 'stem' as const, suffixKr: '', suffixRo: 'da', cnPrefix: '', cnSuffix: '（原形）' },
    { key: 'polite' as const, suffixKr: '', suffixRo: 'yo', cnPrefix: '', cnSuffix: '（敬语）' },
    { key: 'past' as const, suffixKr: '', suffixRo: 'eosseoyo', cnPrefix: '', cnSuffix: '了（过去时）' },
    { key: 'future' as const, suffixKr: '', suffixRo: 'geoyeyo', cnPrefix: '将要', cnSuffix: '' },
  ];

  for (const v of VERB_STEMS) {
    for (const form of verbForms) {
      if (result.length >= targetCount) break;
      const kr = v[form.key];
      addEntry({
        korean: kr,
        roman: `${v.romanBase}${form.suffixRo}`,
        chinese: `${form.cnPrefix}${v.cn}${form.cnSuffix}`,
        pos: '动词',
        category: v.cat,
        exampleKr: `오늘도 열심히 ${v.polite}.`,
        exampleCn: `今天也努力地${v.cn}。`,
      });
    }

    // Additional high-frequency verb patterns
    const stemBase = v.stem.slice(0, -1);
    const extraVerbPatterns = [
      { kr: `${stemBase}고 싶어요`, ro: `${v.romanBase}go sipeoyo`, cn: `想${v.cn}` },
      { kr: `${stemBase}지 마세요`, ro: `${v.romanBase}ji maseyo`, cn: `请不要${v.cn}` },
      { kr: `${stemBase}세요`, ro: `${v.romanBase}seyo`, cn: `请${v.cn}` },
      { kr: `${stemBase}고 있어요`, ro: `${v.romanBase}go isseoyo`, cn: `正在${v.cn}` },
      { kr: `안 ${v.polite}`, ro: `an ${v.romanBase}yo`, cn: `不${v.cn}` },
      { kr: `못 ${v.polite}`, ro: `mot ${v.romanBase}yo`, cn: `没法${v.cn}` },
      { kr: `${stemBase}면 돼요`, ro: `${v.romanBase}myeon dwaeyo`, cn: `只要${v.cn}就行` },
      { kr: `${stemBase}기 전에`, ro: `${v.romanBase}gi jeone`, cn: `在${v.cn}之前` },
      { kr: `${stemBase}고 나서`, ro: `${v.romanBase}go naseo`, cn: `${v.cn}之后` },
      { kr: `${stemBase}ㄹ까요?`, ro: `${v.romanBase}lkkayo?`, cn: `要${v.cn}吗？` },
    ];

    for (const pat of extraVerbPatterns) {
      if (result.length >= targetCount) break;
      addEntry({
        korean: pat.kr,
        roman: pat.ro,
        chinese: pat.cn,
        pos: '常用句型',
        category: v.cat,
        exampleKr: `지금 바로 ${pat.kr}`,
        exampleCn: `现在马上${pat.cn}`,
      });
    }
  }

  // 3. Add adjective forms & degree adverbs
  const adverbs = [
    { kr: '정말', ro: 'jeongmal', cn: '真的' },
    { kr: '너무', ro: 'neomu', cn: '太/非常' },
    { kr: '조금', ro: 'jogeum', cn: '有一点' },
    { kr: '아주', ro: 'aju', cn: '很' },
    { kr: '완전', ro: 'wanjeon', cn: '完全' },
    { kr: '항상', ro: 'hangsang', cn: '总是' },
    { kr: '가끔', ro: 'gakkeum', cn: '偶尔' },
    { kr: '벌써', ro: 'beolsseo', cn: '已经' },
    { kr: '아직', ro: 'ajik', cn: '还' },
    { kr: '다행히', ro: 'dahaenghi', cn: '幸好' },
  ];

  for (const adj of ADJ_STEMS) {
    if (result.length >= targetCount) break;
    addEntry({
      korean: adj.stem,
      roman: `${adj.romanBase}da`,
      chinese: `${adj.cn}（原形）`,
      pos: '形容词',
      category: adj.cat,
      exampleKr: `오늘 기분이 참 ${adj.polite}.`,
      exampleCn: `今天心情真${adj.cn}。`,
    });
    addEntry({
      korean: adj.polite,
      roman: `${adj.romanBase}yo`,
      chinese: adj.cn,
      pos: '形容词',
      category: adj.cat,
      exampleKr: `이곳은 언제나 ${adj.polite}.`,
      exampleCn: `这里总是很${adj.cn}。`,
    });

    for (const adv of adverbs) {
      if (result.length >= targetCount) break;
      addEntry({
        korean: `${adv.kr} ${adj.polite}`,
        roman: `${adv.ro} ${adj.romanBase}yo`,
        chinese: `${adv.cn}${adj.cn}`,
        pos: '高频短语',
        category: adj.cat,
        exampleKr: `오늘은 ${adv.kr} ${adj.polite}.`,
        exampleCn: `今天${adv.cn}${adj.cn}。`,
      });
    }
  }

  // 4. Add noun + verb collocations
  for (const root of CORE_ROOTS) {
    for (const v of VERB_STEMS) {
      if (result.length >= targetCount) break;
      addEntry({
        korean: `${root.kr} ${v.polite}`,
        roman: `${root.roman} ${v.romanBase}yo`,
        chinese: `${v.cn}${root.cn}`,
        pos: '常用搭配',
        category: root.cat,
        exampleKr: `우리는 ${root.kr} ${v.polite}.`,
        exampleCn: `我们${v.cn}${root.cn}。`,
      });
    }
  }

  // 5. Fill remaining up to 10000 with K-drama & daily collocations
  const subjects = [
    { kr: '내가', ro: 'naega', cn: '我' },
    { kr: '우리가', ro: 'uriga', cn: '我们' },
    { kr: '너를', ro: 'neoreul', cn: '你' },
    { kr: '오늘', ro: 'oneul', cn: '今天' },
    { kr: '내일', ro: 'naeil', cn: '明天' },
    { kr: '지금', ro: 'jigeum', cn: '现在' },
    { kr: '항상', ro: 'hangsang', cn: '总是' },
    { kr: '꼭', ro: 'kkok', cn: '一定' },
    { kr: '아침에', ro: 'achime', cn: '早上' },
    { kr: '저녁에', ro: 'jeonyeoge', cn: '晚上' },
    { kr: '주말에', ro: 'jumare', cn: '周末' },
    { kr: '집에서', ro: 'jibeseo', cn: '在家' },
    { kr: '학교에서', ro: 'hakgyoeseo', cn: '在学校' },
    { kr: '회사에서', ro: 'hoesaeseo', cn: '在公司' },
    { kr: '서울에서', ro: 'seoureseo', cn: '在首尔' },
    { kr: '혼자서', ro: 'honjaseo', cn: '一个人' },
    { kr: '다 같이', ro: 'da gachi', cn: '大家一起' },
    { kr: '갑자기', ro: 'gapjagi', cn: '突然' },
    { kr: '천천히', ro: 'cheoncheonhi', cn: '慢慢地' },
    { kr: '빨리', ro: 'ppalli', cn: '快点' },
  ];

  let idx = 0;
  while (result.length < targetCount && idx < 20000) {
    const subj = subjects[idx % subjects.length];
    const verb = VERB_STEMS[Math.floor(idx / subjects.length) % VERB_STEMS.length];
    const adv = adverbs[Math.floor(idx / (subjects.length * VERB_STEMS.length)) % adverbs.length];
    const kr = `${subj.kr} ${adv.kr} ${verb.polite}`;
    const ro = `${subj.ro} ${adv.ro} ${verb.romanBase}yo`;
    const cn = `${subj.cn}${adv.cn}${verb.cn}`;
    addEntry({
      korean: kr,
      roman: ro,
      chinese: cn,
      pos: '韩剧高频表达',
      category: '韩剧高频',
      exampleKr: `${kr}.`,
      exampleCn: `${cn}。`,
    });
    idx++;
  }

  return result;
}

export function generateKDramaSentences(targetCount = 1000): DramaSentenceItem[] {
  const sentences: DramaSentenceItem[] = [];
  const seen = new Set<string>();

  const templates = [
    {
      kr: (n: string, v: string, a: string) => `오늘 ${n} 때문에 ${a} ${v}.`,
      ro: (n: string, v: string, a: string) => `oneul ${n} ttaemune ${a} ${v}.`,
      cn: (n: string, v: string, a: string) => `今天因为${n}，${a}${v}。`,
      cat: '情感独白',
    },
    {
      kr: (n: string, v: string, a: string) => `우리 ${n} 잊지 말고 꼭 ${v}.`,
      ro: (n: string, v: string, a: string) => `uri ${n} itji malgo kkok ${v}.`,
      cn: (n: string, v: string, a: string) => `我们不要忘记${n}，一定要${v}。`,
      cat: '经典约定',
    },
    {
      kr: (n: string, v: string, a: string) => `네가 있어서 내 ${n}이 ${a} ${v}.`,
      ro: (n: string, v: string, a: string) => `nega isseoseo nae ${n}i ${a} ${v}.`,
      cn: (n: string, v: string, a: string) => `因为有你，我的${n}${a}${v}。`,
      cat: '浪漫告白',
    },
    {
      kr: (n: string, v: string, a: string) => `지금 당장 ${n}에 가서 ${v}.`,
      ro: (n: string, v: string, a: string) => `jigeum dangjang ${n}e gaseo ${v}.`,
      cn: (n: string, v: string, a: string) => `现在马上去${n}${v}吧。`,
      cat: '日常行动',
    },
    {
      kr: (n: string, v: string, a: string) => `그날의 ${n}은 아직도 ${a} ${v}.`,
      ro: (n: string, v: string, a: string) => `geunarui ${n}eun ajikdo ${a} ${v}.`,
      cn: (n: string, v: string, a: string) => `那一天的${n}至今依然${a}${v}。`,
      cat: '回忆往事',
    },
  ];

  const adverbs = [
    { kr: '정말', ro: 'jeongmal', cn: '真的' },
    { kr: '너무', ro: 'neomu', cn: '非常' },
    { kr: '항상', ro: 'hangsang', cn: '总是' },
    { kr: '조금', ro: 'jogeum', cn: '有点' },
  ];

  let i = 0;
  while (sentences.length < targetCount && i < 10000) {
    const tpl = templates[i % templates.length];
    const noun = CORE_ROOTS[Math.floor(i / templates.length) % CORE_ROOTS.length];
    const verb = VERB_STEMS[Math.floor(i / (templates.length * CORE_ROOTS.length)) % VERB_STEMS.length];
    const adv = adverbs[i % adverbs.length];
    const drama = DRAMA_TITLES[i % DRAMA_TITLES.length];

    const kr = tpl.kr(noun.kr, verb.polite, adv.kr);
    if (!seen.has(kr)) {
      seen.add(kr);
      sentences.push({
        id: `kd_s_${sentences.length + 1}`,
        drama,
        korean: kr,
        roman: tpl.ro(noun.roman, `${verb.romanBase}yo`, adv.ro),
        chinese: tpl.cn(noun.cn, verb.cn, adv.cn),
        category: tpl.cat,
      });
    }
    i++;
  }

  return sentences;
}

export interface GeneratedDialogueTurn {
  speaker: string;
  role: 'staff' | 'learner';
  korean: string;
  roman: string;
  chinese: string;
}

export interface GeneratedDialogueScenario {
  id: string;
  title: string;
  location: string;
  level: string;
  turns: GeneratedDialogueTurn[];
}

const SCENARIO_TOPICS = [
  { title: '在首尔咖啡馆点单', location: '延南洞 · 咖啡馆', staff: '店员', topicKr: '커피', topicCn: '咖啡' },
  { title: '乘坐地铁问路', location: '弘大入口站 · 2号线', staff: '路人', topicKr: '지하철', topicCn: '地铁' },
  { title: '明洞服装店试穿', location: '明洞 · 潮流服饰店', staff: '店员', topicKr: '옷', topicCn: '衣服' },
  { title: '韩式烤肉店点餐', location: '江南 · 烤肉店', staff: '服务员', topicKr: '삼겹살', topicCn: '五花肉' },
  { title: '便利店结账与加热', location: '首尔 · 24小时便利店', staff: '店员', topicKr: '도시락', topicCn: '便当' },
  { title: '仁川机场办理值机', location: '仁川国际机场 · T1', staff: '地勤', topicKr: '비행기', topicCn: '飞机' },
  { title: '医院挂号看病', location: '首尔 · 内科诊所', staff: '护士', topicKr: '병원', topicCn: '医院' },
  { title: '药店购买感冒药', location: '钟路 · 药店', staff: '药师', topicKr: '약', topicCn: '药' },
  { title: '银行办理换汇', location: '明洞 · 银行网点', staff: '职员', topicKr: '환전', topicCn: '换汇' },
  { title: '酒店前台办理入住', location: '首尔站 · 商务酒店', staff: '前台', topicKr: '예약', topicCn: '预订' },
  { title: '美容院剪发造型', location: '清潭洞 · 美容室', staff: '发型师', topicKr: '머리', topicCn: '头发' },
  { title: '汉江公园野餐点外卖', location: '汝矣岛 · 汉江公园', staff: '朋友', topicKr: '치맥', topicCn: '炸鸡啤酒' },
  { title: '书店寻找韩语教材', location: '光化门 · 教保文库', staff: '店员', topicKr: '책', topicCn: '书' },
  { title: '电影院购买爆米花', location: '龙山 · CGV影院', staff: '职员', topicKr: '영화', topicCn: '电影' },
  { title: '出租车告知目的地', location: '首尔市区 · 出租车', staff: '司机', topicKr: '택시', topicCn: '出租车' },
  { title: '邮局寄送国际快递', location: '首尔 · 中央邮局', staff: '职员', topicKr: '소포', topicCn: '包裹' },
  { title: '健身房咨询办卡', location: '江南 · 健身中心', staff: '教练', topicKr: '운동', topicCn: '运动' },
  { title: '公司初次见面自我介绍', location: '首尔 · 办公室', staff: '同事', topicKr: '회사', topicCn: '公司' },
  { title: '大学校园问路找教室', location: '新村 · 大学校园', staff: '同学', topicKr: '학교', topicCn: '学校' },
  { title: '超市选购水果零食', location: '首尔站 · 大型超市', staff: '店员', topicKr: '과일', topicCn: '水果' },
  { title: '济州岛租车自驾', location: '济州机场 · 租车柜台', staff: '职员', topicKr: '자동차', topicCn: '汽车' },
  { title: '海云台海边散步聊天', location: '釜山 · 海云台', staff: '朋友', topicKr: '바다', topicCn: '大海' },
  { title: '传统市场品尝小吃', location: '广藏市场 · 小吃摊', staff: '摊主', topicKr: '떡볶이', topicCn: '炒年糕' },
  { title: '博物馆预约参观', location: '龙山 · 国立中央博物馆', staff: '工作人员', topicKr: '박물관', topicCn: '博物馆' },
  { title: '演唱会现场核对座位', location: '蚕室 · 奥林匹克体育场', staff: '工作人员', topicKr: '공연', topicCn: '演出' },
];

export function generateDialogueScenarios(targetCount = 50, turnsPerScenario = 8): GeneratedDialogueScenario[] {
  const scenarios: GeneratedDialogueScenario[] = [];

  for (let i = 0; i < targetCount; i++) {
    const base = SCENARIO_TOPICS[i % SCENARIO_TOPICS.length];
    const variant = Math.floor(i / SCENARIO_TOPICS.length) + 1;
    const title = variant > 1 ? `${base.title} (${variant})` : base.title;

    const turns: GeneratedDialogueTurn[] = (
      [
      {
        speaker: base.staff,
        role: 'staff',
        korean: `안녕하세요! 무엇을 도와드릴까요?`,
        roman: `annyeonghaseyo! mueoseul dowadeurilkkayo?`,
        chinese: `您好！请问有什么可以帮您的？`,
      },
      {
        speaker: '你',
        role: 'learner',
        korean: `안녕하세요, ${base.topicKr} 때문에 왔어요.`,
        roman: `annyeonghaseyo, ${base.topicKr} ttaemune wasseoyo.`,
        chinese: `您好，我是因为${base.topicCn}过来的。`,
      },
      {
        speaker: base.staff,
        role: 'staff',
        korean: `네, 잘 오셨어요. 잠시만 기다려 주세요.`,
        roman: `ne, jal osyeosseoyo. jamsiman gidaryeo juseyo.`,
        chinese: `好的，欢迎光临。请稍等一下。`,
      },
      {
        speaker: '你',
        role: 'learner',
        korean: `혹시 추천해 주실 만한 것이 있어요?`,
        roman: `hoksi chucheonhae jusil manhan geosi isseoyo?`,
        chinese: `请问有什么值得推荐的吗？`,
      },
      {
        speaker: base.staff,
        role: 'staff',
        korean: `이것이 요즘 가장 인기가 많아요.`,
        roman: `igeosi yojeum gajang ingiga manayo.`,
        chinese: `这个最近人气最高。`,
      },
      {
        speaker: '你',
        role: 'learner',
        korean: `정말 좋네요! 그럼 이것으로 할게요.`,
        roman: `jeongmal joneyo! geureom igeoseuro halgeyo.`,
        chinese: `真不错！那我就选这个吧。`,
      },
      {
        speaker: base.staff,
        role: 'staff',
        korean: `알겠습니다. 바로 준비해 드리겠습니다.`,
        roman: `algetseumnida. baro junbihae deurigetseumnida.`,
        chinese: `好的，马上为您准备。`,
      },
      {
        speaker: '你',
        role: 'learner',
        korean: `친절하게 도와주셔서 정말 감사합니다!`,
        roman: `chinjeolhage dowajusyeoseo jeongmal gamsahamnida!`,
        chinese: `非常感谢您的热情帮助！`,
      },
    ] as GeneratedDialogueTurn[]
    ).slice(0, turnsPerScenario);

    scenarios.push({
      id: `sc_${i + 1}`,
      title,
      location: base.location,
      level: i % 2 === 0 ? '初级实用' : '进阶日常',
      turns,
    });
  }

  return scenarios;
}

export function buildFullWordGlossary(vocabList: VocabItem[]): Record<string, string> {
  const map: Record<string, string> = {};
  for (const item of vocabList) {
    const clean = item.korean.replace(/[.,!?~"'()]/g, '').trim();
    if (clean && !map[clean]) {
      map[clean] = item.chinese;
    }
  }
  return map;
}

export interface JamoItem {
  char: string;
  roman: string;
  name: string;
  type: 'basic_consonant' | 'tense_consonant' | 'basic_vowel' | 'compound_vowel';
  articulation: string;
  exampleWord: string;
  exampleMeaning: string;
}

export const BASIC_CONSONANTS: JamoItem[] = [
  { char: 'ㄱ', roman: 'g / k', name: '기역', type: 'basic_consonant', articulation: '舌根轻触软腭，类似不送气的 g/k', exampleWord: '가방', exampleMeaning: '书包' },
  { char: 'ㄴ', roman: 'n', name: '니은', type: 'basic_consonant', articulation: '舌尖抵住上齿龈，鼻音 n', exampleWord: '나무', exampleMeaning: '树木' },
  { char: 'ㄷ', roman: 'd / t', name: '디귿', type: 'basic_consonant', articulation: '舌尖抵住上齿龈，不送气 d/t', exampleWord: '다리', exampleMeaning: '桥 / 腿' },
  { char: 'ㄹ', roman: 'r / l', name: '리을', type: 'basic_consonant', articulation: '舌尖轻弹上齿龈，词首近 r，收音近 l', exampleWord: '라면', exampleMeaning: '拉面' },
  { char: 'ㅁ', roman: 'm', name: '미음', type: 'basic_consonant', articulation: '双唇紧闭，鼻音 m', exampleWord: '마음', exampleMeaning: '心意' },
  { char: 'ㅂ', roman: 'b / p', name: '비읍', type: 'basic_consonant', articulation: '双唇轻闭后爆破，不送气 b/p', exampleWord: '바다', exampleMeaning: '大海' },
  { char: 'ㅅ', roman: 's', name: '시옷', type: 'basic_consonant', articulation: '舌尖接近上齿龈摩擦，遇 ㅣ 音近 sh', exampleWord: '사랑', exampleMeaning: '爱' },
  { char: 'ㅇ', roman: 'ng / -', name: '이응', type: 'basic_consonant', articulation: '作初声时不发音，作收音时发后鼻音 ng', exampleWord: '우유', exampleMeaning: '牛奶' },
  { char: 'ㅈ', roman: 'j', name: '지읒', type: 'basic_consonant', articulation: '舌面抵住硬腭前部，不送气 j', exampleWord: '자전거', exampleMeaning: '自行车' },
  { char: 'ㅊ', roman: 'ch', name: '치읓', type: 'basic_consonant', articulation: '与 ㅈ 同位但强送气，发 ch', exampleWord: '친구', exampleMeaning: '朋友' },
  { char: 'ㅋ', roman: 'k', name: '키읔', type: 'basic_consonant', articulation: '与 ㄱ 同位但强送气，发 k', exampleWord: '커피', exampleMeaning: '咖啡' },
  { char: 'ㅌ', roman: 't', name: '티읕', type: 'basic_consonant', articulation: '与 ㄷ 同位但强送气，发 t', exampleWord: '토마토', exampleMeaning: '番茄' },
  { char: 'ㅍ', roman: 'p', name: '피읖', type: 'basic_consonant', articulation: '与 ㅂ 同位但强送气，发 p', exampleWord: '포도', exampleMeaning: '葡萄' },
  { char: 'ㅎ', roman: 'h', name: '히읗', type: 'basic_consonant', articulation: '声门摩擦送气，发 h', exampleWord: '하늘', exampleMeaning: '天空' },
];

export const TENSE_CONSONANTS: JamoItem[] = [
  { char: 'ㄲ', roman: 'kk', name: '쌍기역', type: 'tense_consonant', articulation: '声门紧缩，用力挤出不送气 kk', exampleWord: '까치', exampleMeaning: '喜鹊' },
  { char: 'ㄸ', roman: 'tt', name: '쌍디귿', type: 'tense_consonant', articulation: '舌尖紧抵齿龈，用力挤出不送气 tt', exampleWord: '딸기', exampleMeaning: '草莓' },
  { char: 'ㅃ', roman: 'pp', name: '쌍비읍', type: 'tense_consonant', articulation: '双唇紧闭，用力挤出不送气 pp', exampleWord: '빵', exampleMeaning: '面包' },
  { char: 'ㅆ', roman: 'ss', name: '쌍시옷', type: 'tense_consonant', articulation: '舌尖用力摩擦，发紧音 ss', exampleWord: '쓰다', exampleMeaning: '写 / 苦' },
  { char: 'ㅉ', roman: 'jj', name: '쌍지읒', type: 'tense_consonant', articulation: '舌面紧抵硬腭，用力挤出不送气 jj', exampleWord: '짜다', exampleMeaning: '咸' },
];

export const BASIC_VOWELS: JamoItem[] = [
  { char: 'ㅏ', roman: 'a', name: '아', type: 'basic_vowel', articulation: '口自然张大，舌尖放低，发 a', exampleWord: '아이', exampleMeaning: '孩子' },
  { char: 'ㅑ', roman: 'ya', name: '야', type: 'basic_vowel', articulation: '先发短 ㅣ 再滑向 ㅏ，发 ya', exampleWord: '야구', exampleMeaning: '棒球' },
  { char: 'ㅓ', roman: 'eo', name: '어', type: 'basic_vowel', articulation: '口型比 ㅏ 略小，舌根微后缩，发 eo', exampleWord: '어머니', exampleMeaning: '母亲' },
  { char: 'ㅕ', roman: 'yeo', name: '여', type: 'basic_vowel', articulation: '先发短 ㅣ 再滑向 ㅓ，发 yeo', exampleWord: '여름', exampleMeaning: '夏天' },
  { char: 'ㅗ', roman: 'o', name: '오', type: 'basic_vowel', articulation: '双唇拢圆向前突出，发 o', exampleWord: '오늘', exampleMeaning: '今天' },
  { char: 'ㅛ', roman: 'yo', name: '요', type: 'basic_vowel', articulation: '先发短 ㅣ 再滑向 ㅗ，发 yo', exampleWord: '요리', exampleMeaning: '料理' },
  { char: 'ㅜ', roman: 'u', name: '우', type: 'basic_vowel', articulation: '双唇比 ㅗ 更小更圆，发 u', exampleWord: '우산', exampleMeaning: '雨伞' },
  { char: 'ㅠ', roman: 'yu', name: '유', type: 'basic_vowel', articulation: '先发短 ㅣ 再滑向 ㅜ，发 yu', exampleWord: '유리', exampleMeaning: '玻璃' },
  { char: 'ㅡ', roman: 'eu', name: '으', type: 'basic_vowel', articulation: '双唇向两侧扁平拉开，舌面抬起，发 eu', exampleWord: '으뜸', exampleMeaning: '第一 / 最佳' },
  { char: 'ㅣ', roman: 'i', name: '이', type: 'basic_vowel', articulation: '嘴角向两侧微展，舌尖抵下齿，发 i', exampleWord: '이름', exampleMeaning: '名字' },
];

export const COMPOUND_VOWELS: JamoItem[] = [
  { char: 'ㅐ', roman: 'ae', name: '애', type: 'compound_vowel', articulation: '口型比 ㅔ 略大，现代韩语中与 ㅔ 接近', exampleWord: '개', exampleMeaning: '小狗' },
  { char: 'ㅒ', roman: 'yae', name: '얘', type: 'compound_vowel', articulation: '先发短 ㅣ 再滑向 ㅐ，发 yae', exampleWord: '얘기', exampleMeaning: '故事 / 谈话' },
  { char: 'ㅔ', roman: 'e', name: '에', type: 'compound_vowel', articulation: '口半开，舌面略高，发 e', exampleWord: '세상', exampleMeaning: '世界' },
  { char: 'ㅖ', roman: 'ye', name: '예', type: 'compound_vowel', articulation: '先发短 ㅣ 再滑向 ㅔ，发 ye', exampleWord: '예쁘다', exampleMeaning: '漂亮' },
  { char: 'ㅘ', roman: 'wa', name: '와', type: 'compound_vowel', articulation: 'ㅗ 与 ㅏ 快速连读，发 wa', exampleWord: '과일', exampleMeaning: '水果' },
  { char: 'ㅙ', roman: 'wae', name: '왜', type: 'compound_vowel', articulation: 'ㅗ 与 ㅐ 快速连读，发 wae', exampleWord: '왜', exampleMeaning: '为什么' },
  { char: 'ㅚ', roman: 'oe', name: '외', type: 'compound_vowel', articulation: '现代首尔音多读作 we', exampleWord: '외국', exampleMeaning: '外国' },
  { char: 'ㅝ', roman: 'wo', name: '워', type: 'compound_vowel', articulation: 'ㅜ 与 ㅓ 快速连读，发 wo', exampleWord: '원', exampleMeaning: '韩元 / 圆' },
  { char: 'ㅞ', roman: 'we', name: '웨', type: 'compound_vowel', articulation: 'ㅜ 与 ㅔ 快速连读，发 we', exampleWord: '웨딩', exampleMeaning: '婚礼' },
  { char: 'ㅟ', roman: 'wi', name: '위', type: 'compound_vowel', articulation: 'ㅜ 与 ㅣ 快速连读，发 wi', exampleWord: '위', exampleMeaning: '上面' },
  { char: 'ㅢ', roman: 'ui', name: '의', type: 'compound_vowel', articulation: 'ㅡ 与 ㅣ 快速连读，词首读 ui，词中常读 i', exampleWord: '의사', exampleMeaning: '医生' },
];

// Unicode Hangul Syllable Composition Tables
export const INITIAL_JAMO = ['ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'];
export const INITIAL_ROMAN = ['g', 'kk', 'n', 'd', 'tt', 'r', 'm', 'b', 'pp', 's', 'ss', '', 'j', 'jj', 'ch', 'k', 't', 'p', 'h'];

export const MEDIAL_JAMO = ['ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ', 'ㅗ', 'ㅘ', 'ㅙ', 'ㅚ', 'ㅛ', 'ㅜ', 'ㅝ', 'ㅞ', 'ㅟ', 'ㅠ', 'ㅡ', 'ㅢ', 'ㅣ'];
export const MEDIAL_ROMAN = ['a', 'ae', 'ya', 'yae', 'eo', 'e', 'yeo', 'ye', 'o', 'wa', 'wae', 'oe', 'yo', 'u', 'wo', 'we', 'wi', 'yu', 'eu', 'ui', 'i'];

export const FINAL_JAMO = ['', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ', 'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'];
export const FINAL_ROMAN = ['', 'k', 'k', 'k', 'n', 'n', 'n', 't', 'l', 'k', 'm', 'p', 'l', 'l', 'p', 'l', 'm', 'p', 'p', 't', 't', 'ng', 't', 't', 'k', 't', 'p', 't'];

export function composeHangul(initialIdx: number, medialIdx: number, finalIdx: number = 0): { char: string; roman: string } {
  const code = 0xac00 + initialIdx * 588 + medialIdx * 28 + finalIdx;
  const char = String.fromCharCode(code);
  const roman = `${INITIAL_ROMAN[initialIdx]}${MEDIAL_ROMAN[medialIdx]}${FINAL_ROMAN[finalIdx]}`;
  return { char, roman };
}

export interface VocabItem {
  id: string;
  korean: string;
  roman: string;
  chinese: string;
  pos: string;
  category: '日常问候' | '咖啡与美食' | '交通出行' | '购物数字' | '情感表达' | '韩剧高频';
  exampleKr: string;
  exampleCn: string;
}

export const VOCABULARY_LIST: VocabItem[] = [
  // 日常问候
  { id: 'v1', korean: '안녕하세요', roman: 'annyeonghaseyo', chinese: '您好', pos: '敬语问候', category: '日常问候', exampleKr: '안녕하세요, 만나서 반갑습니다.', exampleCn: '您好，很高兴见到您。' },
  { id: 'v2', korean: '감사합니다', roman: 'gamsahamnida', chinese: '非常感谢', pos: '敬语表达', category: '日常问候', exampleKr: '도와주셔서 정말 감사합니다.', exampleCn: '非常感谢您的帮助。' },
  { id: 'v3', korean: '죄송합니다', roman: 'joesonghamnida', chinese: '对不起 / 抱歉', pos: '敬语表达', category: '日常问候', exampleKr: '늦어서 정말 죄송합니다.', exampleCn: '迟到了真的非常抱歉。' },
  { id: 'v4', korean: '괜찮아요', roman: 'gwaenchanayo', chinese: '没关系 / 可以', pos: '形容词', category: '日常问候', exampleKr: '천천히 하셔도 괜찮아요.', exampleCn: '慢一点做也没关系。' },
  { id: 'v15', korean: '잘 지냈어요?', roman: 'jal jinaesseoyo?', chinese: '过得好吗？', pos: '问候语', category: '日常问候', exampleKr: '오랜만이에요, 그동안 잘 지냈어요?', exampleCn: '好久不见，这段时间过得好吗？' },
  { id: 'v16', korean: '안녕히 가세요', roman: 'annyeonghi gaseyo', chinese: '再见（对离开的人）', pos: '敬语告别', category: '日常问候', exampleKr: '조심히 들어가세요, 안녕히 가세요.', exampleCn: '请小心回去，再见。' },
  { id: 'v17', korean: '수고하셨습니다', roman: 'sugohasyeotseumnida', chinese: '辛苦了', pos: '敬语表达', category: '日常问候', exampleKr: '오늘 하루도 정말 수고하셨습니다.', exampleCn: '今天一天也真的辛苦了。' },
  { id: 'v18', korean: '잠깐만요', roman: 'jamkkanmanyo', chinese: '请等一下', pos: '常用语', category: '日常问候', exampleKr: '잠깐만요, 저도 같이 가요!', exampleCn: '等一下，我也一起去！' },
  { id: 'v19', korean: '부탁합니다', roman: 'butakhamnida', chinese: '拜托了 / 请多关照', pos: '敬语表达', category: '日常问候', exampleKr: '앞으로 잘 부탁합니다.', exampleCn: '今后请多多关照。' },
  { id: 'v20', korean: '천만에요', roman: 'cheonmaneyo', chinese: '不客气', pos: '礼貌回应', category: '日常问候', exampleKr: '아니에요, 천만에요.', exampleCn: '哪里哪里，不客气。' },

  // 咖啡与美食
  { id: 'v5', korean: '아이스 아메리카노', roman: 'aiseu amerikaeno', chinese: '冰美式咖啡', pos: '名词', category: '咖啡与美食', exampleKr: '아이스 아메리카노 한 잔 주세요.', exampleCn: '请给我一杯冰美式咖啡。' },
  { id: 'v6', korean: '맛있어요', roman: 'masisseoyo', chinese: '很好吃 / 好喝', pos: '形容词', category: '咖啡与美食', exampleKr: '이 김치찌개가 정말 맛있어요!', exampleCn: '这个泡菜汤真的很好吃！' },
  { id: 'v7', korean: '배고파요', roman: 'baegopayo', chinese: '肚子饿了', pos: '形容词', category: '咖啡与美食', exampleKr: '점심시간이라서 너무 배고파요.', exampleCn: '到午饭时间了，肚子好饿。' },
  { id: 'v8', korean: '계산서', roman: 'gyesanseo', chinese: '账单 / 小票', pos: '名词', category: '咖啡与美食', exampleKr: '여기 계산서 좀 주세요.', exampleCn: '请把这里的账单拿给我。' },
  { id: 'v21', korean: '잘 먹겠습니다', roman: 'jal meokgetseumnida', chinese: '我开动了', pos: '餐前礼貌语', category: '咖啡与美食', exampleKr: '차려 주셔서 감사합니다, 잘 먹겠습니다!', exampleCn: '谢谢准备饭菜，我开动了！' },
  { id: 'v22', korean: '잘 먹었습니다', roman: 'jal meogeotseumnida', chinese: '我吃好了（谢谢款待）', pos: '餐后礼貌语', category: '咖啡与美食', exampleKr: '정말 맛있게 잘 먹었습니다.', exampleCn: '吃得非常香，谢谢款待。' },
  { id: 'v23', korean: '포장돼요?', roman: 'pojangdwaeyo?', chinese: '可以打包吗？', pos: '疑问句', category: '咖啡与美食', exampleKr: '남은 음식은 포장돼요?', exampleCn: '剩下的食物可以打包吗？' },
  { id: 'v24', korean: '매워요', roman: 'maewoyo', chinese: '好辣', pos: '形容词', category: '咖啡与美食', exampleKr: '떡볶이가 생각보다 많이 매워요.', exampleCn: '炒年糕比想象中辣很多。' },
  { id: 'v25', korean: '삼겹살', roman: 'samgyeopsal', chinese: '五花肉', pos: '名词', category: '咖啡与美食', exampleKr: '오늘 저녁에 삼겹살 먹을래요?', exampleCn: '今天晚上要吃五花肉吗？' },
  { id: 'v26', korean: '치맥', roman: 'chimaek', chinese: '炸鸡配啤酒', pos: '名词', category: '咖啡与美食', exampleKr: '한강에서 치맥 먹는 게 최고예요.', exampleCn: '在汉江边吃炸鸡配啤酒最棒了。' },

  // 交通出行
  { id: 'v9', korean: '지하철역', roman: 'jihacheollyeok', chinese: '地铁站', pos: '名词', category: '交通出行', exampleKr: '가장 가까운 지하철역이 어디예요?', exampleCn: '最近的地铁站在哪里？' },
  { id: 'v10', korean: '오른쪽', roman: 'oreunjjok', chinese: '右边', pos: '名词', category: '交通出行', exampleKr: '사거리에서 오른쪽으로 가세요.', exampleCn: '请在十字路口往右走。' },
  { id: 'v27', korean: '왼쪽', roman: 'oenjjok', chinese: '左边', pos: '名词', category: '交通出行', exampleKr: '은행은 왼쪽 건물에 있어요.', exampleCn: '银行在左边的建筑里。' },
  { id: 'v28', korean: '직진', roman: 'jikjin', chinese: '直走', pos: '名词', category: '交通出行', exampleKr: '여기서 쭉 직진하면 나와요.', exampleCn: '从这里一直直走就到了。' },
  { id: 'v29', korean: '갈아타다', roman: 'garatada', chinese: '换乘', pos: '动词', category: '交通出行', exampleKr: '서울역에서 4호선으로 갈아타세요.', exampleCn: '请在首尔站换乘4号线。' },
  { id: 'v30', korean: '택시', roman: 'taeksi', chinese: '出租车', pos: '名词', category: '交通出行', exampleKr: '시간이 없어서 택시를 탔어요.', exampleCn: '因为没时间了，所以打了出租车。' },
  { id: 'v31', korean: '공항', roman: 'gonghang', chinese: '机场', pos: '名词', category: '交通出行', exampleKr: '인천공항까지 얼마나 걸려요?', exampleCn: '到仁川机场需要多久？' },
  { id: 'v32', korean: '출구', roman: 'chulgu', chinese: '出口', pos: '名词', category: '交通出行', exampleKr: '3번 출구 앞에서 만나요.', exampleCn: '我们在3号出口前见面吧。' },

  // 购物数字
  { id: 'v11', korean: '얼마예요?', roman: 'eolmayeyo?', chinese: '多少钱？', pos: '疑问句', category: '购物数字', exampleKr: '이 티셔츠는 얼마예요?', exampleCn: '这件T恤多少钱？' },
  { id: 'v12', korean: '깎아 주세요', roman: 'kkakka juseyo', chinese: '请便宜一点', pos: '请求句', category: '购物数字', exampleKr: '조금만 깎아 주세요.', exampleCn: '请稍微便宜一点吧。' },
  { id: 'v33', korean: '입어 봐도 돼요?', roman: 'ibeo bwado dwaeyo?', chinese: '可以试穿吗？', pos: '疑问句', category: '购物数字', exampleKr: '이 재킷 한 번 입어 봐도 돼요?', exampleCn: '这件夹克可以试穿一下吗？' },
  { id: 'v34', korean: '영수증', roman: 'yeongsujeung', chinese: '发票 / 收据', pos: '名词', category: '购物数字', exampleKr: '영수증 버리지 마세요.', exampleCn: '请不要扔掉收据。' },
  { id: 'v35', korean: '카드', roman: 'kadeu', chinese: '银行卡 / 信用卡', pos: '名词', category: '购物数字', exampleKr: '카드로 결제할게요.', exampleCn: '我用刷卡支付。' },
  { id: 'v36', korean: '현금', roman: 'hyeongeum', chinese: '现金', pos: '名词', category: '购物数字', exampleKr: '현금으로 내면 할인돼요?', exampleCn: '用现金支付有折扣吗？' },
  { id: 'v37', korean: '면세', roman: 'myeonse', chinese: '免税', pos: '名词', category: '购物数字', exampleKr: '여권이 있으면 면세 받을 수 있어요.', exampleCn: '有护照的话可以享受免税。' },

  // 情感表达
  { id: 'v13', korean: '행복해요', roman: 'haengbokaeyo', chinese: '很幸福 / 开心', pos: '形容词', category: '情感表达', exampleKr: '오늘 날씨가 좋아서 행복해요.', exampleCn: '今天天气很好，觉得很幸福。' },
  { id: 'v14', korean: '보고 싶어요', roman: 'bogo sipeoyo', chinese: '想念你 / 想见你', pos: '动词短语', category: '情感表达', exampleKr: '한국에 있는 친구가 보고 싶어요.', exampleCn: '很想念在韩国的朋友。' },
  { id: 'v38', korean: '사랑해요', roman: 'saranghaeyo', chinese: '我爱你', pos: '动词', category: '情感表达', exampleKr: '진심으로 많이 사랑해요.', exampleCn: '真心非常爱你。' },
  { id: 'v39', korean: '고마워요', roman: 'gomawoyo', chinese: '谢谢你', pos: '形容词', category: '情感表达', exampleKr: '항상 내 옆에 있어 줘서 고마워요.', exampleCn: '谢谢你一直陪在我身边。' },
  { id: 'v40', korean: '미안해요', roman: 'mianhaeyo', chinese: '对不起', pos: '形容词', category: '情感表达', exampleKr: '그때는 내가 정말 미안해요.', exampleCn: '那时候我真的很对不起。' },
  { id: 'v41', korean: '걱정하지 마세요', roman: 'geokjeonghaji maseyo', chinese: '请不要担心', pos: '安慰语', category: '情感表达', exampleKr: '다 잘될 거니까 걱정하지 마세요.', exampleCn: '一切都会顺利的，请不要担心。' },
  { id: 'v42', korean: '화이팅!', roman: 'hwaiting!', chinese: '加油！', pos: '感叹词', category: '情感表达', exampleKr: '내일 시험도 화이팅!', exampleCn: '明天的考试也加油！' },

  // 韩剧高频
  { id: 'v43', korean: '진짜요?', roman: 'jinjjayo?', chinese: '真的吗？', pos: '感叹词', category: '韩剧高频', exampleKr: '어머, 그게 진짜요?', exampleCn: '天哪，那是真的吗？' },
  { id: 'v44', korean: '대박!', roman: 'daebak!', chinese: '太厉害了 / 绝了！', pos: '感叹词', category: '韩剧高频', exampleKr: '우와, 이 드라마 완전 대박!', exampleCn: '哇，这部剧简直绝了！' },
  { id: 'v45', korean: '어떡해', roman: 'eotteokhae', chinese: '怎么办', pos: '感叹词', category: '韩剧高频', exampleKr: '비가 오는데 우산이 없어, 어떡해!', exampleCn: '下雨了却没有伞，怎么办！' },
  { id: 'v46', korean: '왜 그래요?', roman: 'wae geuraeyo?', chinese: '怎么了？', pos: '疑问句', category: '韩剧高频', exampleKr: '표정이 안 좋은데 무슨 일 있어요? 왜 그래요?', exampleCn: '脸色不太好，发生什么事了吗？怎么了？' },
  { id: 'v47', korean: '약속', roman: 'yaksok', chinese: '约定', pos: '名词', category: '韩剧高频', exampleKr: '우리 절대 잊지 말자고 약속했잖아.', exampleCn: '我们不是约定好绝对不会忘记的吗。' },
  { id: 'v48', korean: '운명', roman: 'unmyeong', chinese: '命运', pos: '名词', category: '韩剧高频', exampleKr: '우리가 다시 만난 건 운명이에요.', exampleCn: '我们再次相遇是命运的安排。' },
  { id: 'v49', korean: '비밀', roman: 'bimil', chinese: '秘密', pos: '名词', category: '韩剧高频', exampleKr: '이건 우리 둘만의 비밀이에요.', exampleCn: '这是只属于我们两个人的秘密。' },
  { id: 'v50', korean: '오해', roman: 'ohae', chinese: '误会', pos: '名词', category: '韩剧高频', exampleKr: '그건 완전히 오해예요, 제 말 좀 들어 보세요.', exampleCn: '那完全是误会，请听我解释。' },
  { id: 'v51', korean: '진심', roman: 'jinsim', chinese: '真心', pos: '名词', category: '韩剧高频', exampleKr: '내 진심이 너에게 닿았으면 좋겠어.', exampleCn: '希望我的真心能够传达到你那里。' },
  { id: 'v52', korean: '기억', roman: 'gieok', chinese: '记忆', pos: '名词', category: '韩剧高频', exampleKr: '그날의 기억이 아직도 생생해요.', exampleCn: '那一天的记忆至今依然历历在目。' },
];

export interface GrammarPattern {
  id: string;
  pattern: string;
  meaning: string;
  level: string;
  category: '入门基础' | '时态与否定' | '连接与因果' | '中高级表达';
  rule: string;
  stems: {
    stem: string;
    stemMeaning: string;
    conjugated: string;
    roman: string;
    fullSentence: string;
    fullChinese: string;
  }[];
}

export const GRAMMAR_PATTERNS: GrammarPattern[] = [
  {
    id: 'g1',
    pattern: '-아/어요',
    meaning: '非格式体敬语终结词尾（现在时）',
    level: 'TOPIK I · 入门',
    category: '入门基础',
    rule: '词干末音节元音为 ㅏ, ㅗ 时接 -아요；其他元音接 -어요；하다 变为 해요。',
    stems: [
      { stem: '가다', stemMeaning: '去', conjugated: '가요', roman: 'gayo', fullSentence: '저는 오늘 서울에 가요.', fullChinese: '我今天去首尔。' },
      { stem: '먹다', stemMeaning: '吃', conjugated: '먹어요', roman: 'meogeoyo', fullSentence: '점심에 비빔밥을 먹어요.', fullChinese: '午饭吃拌饭。' },
      { stem: '공부하다', stemMeaning: '学习', conjugated: '공부해요', roman: 'gongbuhaeyo', fullSentence: '매일 한국어를 공부해요.', fullChinese: '每天学习韩语。' },
    ],
  },
  {
    id: 'g2',
    pattern: '-습니다/ㅂ니다',
    meaning: '格式体敬语终结词尾（正式场合）',
    level: 'TOPIK I · 入门',
    category: '入门基础',
    rule: '词干有收音时接 -습니다；无收音或 ㄹ 收音时接 -ㅂ니다。',
    stems: [
      { stem: '감사하다', stemMeaning: '感谢', conjugated: '감사합니다', roman: 'gamsahamnida', fullSentence: '도와주셔서 정말 감사합니다.', fullChinese: '非常感谢您的帮助。' },
      { stem: '반갑다', stemMeaning: '高兴', conjugated: '반갑습니다', roman: 'bangapseumnida', fullSentence: '만나서 정말 반갑습니다.', fullChinese: '见到您真的很高兴。' },
    ],
  },
  {
    id: 'g3',
    pattern: '-을/를 주세요',
    meaning: '礼貌请求：“请给我……”',
    level: 'TOPIK I · 入门',
    category: '入门基础',
    rule: '名词有收音时接 -을 주세요；无收音时接 -를 주세요。',
    stems: [
      { stem: '물', stemMeaning: '水（有收音）', conjugated: '물을 주세요', roman: 'mureul juseyo', fullSentence: '물 한 잔만 주세요.', fullChinese: '请给我一杯水。' },
      { stem: '커피', stemMeaning: '咖啡（无收音）', conjugated: '커피를 주세요', roman: 'keopireul juseyo', fullSentence: '따뜻한 커피를 주세요.', fullChinese: '请给我一杯热咖啡。' },
    ],
  },
  {
    id: 'g4',
    pattern: '-(으)세요',
    meaning: '敬语命令/请求：“请……”',
    level: 'TOPIK I · 入门',
    category: '入门基础',
    rule: '词干有收音接 -으세요；无收音或 ㄹ 收音接 -세요。',
    stems: [
      { stem: '앉다', stemMeaning: '坐', conjugated: '앉으세요', roman: 'anjeuseyo', fullSentence: '여기에 편하게 앉으세요.', fullChinese: '请在这里舒舒服服地坐吧。' },
      { stem: '가다', stemMeaning: '去/走', conjugated: '가세요', roman: 'gaseyo', fullSentence: '조심히 들어가세요.', fullChinese: '请小心回去。' },
    ],
  },
  {
    id: 'g5',
    pattern: '-았/었어요',
    meaning: '过去时态：“……了”',
    level: 'TOPIK I · 初级',
    category: '时态与否定',
    rule: '词干末音节元音为 ㅏ, ㅗ 时接 -았어요；其他接 -었어요；하다 变为 했어요。',
    stems: [
      { stem: '만나다', stemMeaning: '见面', conjugated: '만났어요', roman: 'mannasseoyo', fullSentence: '어제 친구를 만났어요.', fullChinese: '昨天见了朋友。' },
      { stem: '먹다', stemMeaning: '吃', conjugated: '먹었어요', roman: 'meogeosseoyo', fullSentence: '아침에 빵을 먹었어요.', fullChinese: '早上吃了面包。' },
    ],
  },
  {
    id: 'g6',
    pattern: '-(으)ㄹ 거예요',
    meaning: '将来时态/计划：“将要……”',
    level: 'TOPIK I · 初级',
    category: '时态与否定',
    rule: '词干有收音接 -을 거예요；无收音或 ㄹ 收音接 -ㄹ 거예요。',
    stems: [
      { stem: '가다', stemMeaning: '去', conjugated: '갈 거예요', roman: 'gal geoyeyo', fullSentence: '내일 제주도에 갈 거예요.', fullChinese: '明天要去济州岛。' },
      { stem: '공부하다', stemMeaning: '学习', conjugated: '공부할 거예요', roman: 'gongbuhal geoyeyo', fullSentence: '주말에 집에서 공부할 거예요.', fullChinese: '周末要在家里学习。' },
    ],
  },
  {
    id: 'g7',
    pattern: '-고 있어요',
    meaning: '现在进行时：“正在……”',
    level: 'TOPIK I · 初级',
    category: '时态与否定',
    rule: '直接接在动词词干后，表示动作正在进行。',
    stems: [
      { stem: '듣다', stemMeaning: '听', conjugated: '듣고 있어요', roman: 'deutgo isseoyo', fullSentence: '지금 한국 음악을 듣고 있어요.', fullChinese: '现在正在听韩国音乐。' },
      { stem: '기다리다', stemMeaning: '等待', conjugated: '기다리고 있어요', roman: 'gidarigo isseoyo', fullSentence: '카페에서 친구를 기다리고 있어요.', fullChinese: '正在咖啡馆等朋友。' },
    ],
  },
  {
    id: 'g8',
    pattern: '안 / -지 않아요',
    meaning: '否定表达：“不……”',
    level: 'TOPIK I · 初级',
    category: '时态与否定',
    rule: '谓词前加 안，或词干后接 -지 않아요。',
    stems: [
      { stem: '먹다', stemMeaning: '吃', conjugated: '안 먹어요', roman: 'an meogeoyo', fullSentence: '배가 불러서 저녁을 안 먹어요.', fullChinese: '因为饱了，所以不吃晚饭。' },
      { stem: '맵다', stemMeaning: '辣', conjugated: '맵지 않아요', roman: 'maepji anayo', fullSentence: '이 음식은 전혀 맵지 않아요.', fullChinese: '这个菜一点都不辣。' },
    ],
  },
  {
    id: 'g9',
    pattern: '-아/어서',
    meaning: '表示原因或先后顺序：“因为……所以……”',
    level: 'TOPIK I · 初级',
    category: '连接与因果',
    rule: '接在谓词词干后，前后主语通常一致，后句不用命令/共动句。',
    stems: [
      { stem: '바쁘다', stemMeaning: '忙', conjugated: '바빠서', roman: 'bappaseo', fullSentence: '오늘 일이 너무 바빠서 못 가요.', fullChinese: '今天工作太忙了，去不了。' },
      { stem: '만나다', stemMeaning: '见面', conjugated: '만나서', roman: 'mannaseo', fullSentence: '오랜만에 만나서 정말 반가워요.', fullChinese: '好久不见，见到你真高兴。' },
    ],
  },
  {
    id: 'g10',
    pattern: '-(으)니까',
    meaning: '表示原因/理由：“因为……”（后可接命令/共动）',
    level: 'TOPIK I · 初级',
    category: '连接与因果',
    rule: '词干有收音接 -으니까；无收音接 -니까。',
    stems: [
      { stem: '춥다', stemMeaning: '冷', conjugated: '추우니까', roman: 'chuunikka', fullSentence: '날씨가 추우니까 따뜻하게 입으세요.', fullChinese: '天气冷，请穿暖和一点。' },
      { stem: '늦다', stemMeaning: '晚', conjugated: '늦었으니까', roman: 'neujeosseunikka', fullSentence: '시간이 늦었으니까 택시를 탑시다.', fullChinese: '时间晚了，我们打车吧。' },
    ],
  },
  {
    id: 'g11',
    pattern: '-지만 / -(으)는데',
    meaning: '表示转折或背景铺垫：“虽然……但是……”',
    level: 'TOPIK I · 初级',
    category: '连接与因果',
    rule: '-지만 直接接词干表转折；-(으)는데 兼表背景与轻微转折。',
    stems: [
      { stem: '어렵다', stemMeaning: '难', conjugated: '어렵지만', roman: 'eoryeopjiman', fullSentence: '한국어는 조금 어렵지만 재미있어요.', fullChinese: '韩语虽然有点难，但是很有趣。' },
      { stem: '비싸다', stemMeaning: '贵', conjugated: '비싼데', roman: 'bissande', fullSentence: '이 옷은 좀 비싼데 정말 예뻐요.', fullChinese: '这件衣服有点贵，但真的很漂亮。' },
    ],
  },
  {
    id: 'g12',
    pattern: '-(으)면',
    meaning: '表示假设条件：“如果……的话”',
    level: 'TOPIK I · 初级',
    category: '连接与因果',
    rule: '词干有收音接 -으면；无收音或 ㄹ 收音接 -면。',
    stems: [
      { stem: '있다', stemMeaning: '有', conjugated: '있으면', roman: 'isseumyeon', fullSentence: '시간이 있으면 같이 커피 마셔요.', fullChinese: '如果有时间的话，一起喝杯咖啡吧。' },
      { stem: '오다', stemMeaning: '来', conjugated: '오면', roman: 'omyeon', fullSentence: '비가 오면 집에 있을 거예요.', fullChinese: '如果下雨的话，我就待在家里。' },
    ],
  },
  {
    id: 'g13',
    pattern: '-고 싶어요',
    meaning: '表示说话人的愿望：“想……”',
    level: 'TOPIK I · 初级',
    category: '中高级表达',
    rule: '直接接在动词词干后，无论词干是否有收音，均接 -고 싶어요。',
    stems: [
      { stem: '보다', stemMeaning: '看', conjugated: '보고 싶어요', roman: 'bogo sipeoyo', fullSentence: '한국 영화를 보고 싶어요.', fullChinese: '想看韩国电影。' },
      { stem: '여행하다', stemMeaning: '旅行', conjugated: '여행하고 싶어요', roman: 'yeohaenghago sipeoyo', fullSentence: '제주도에 여행하고 싶어요.', fullChinese: '想去济州岛旅行。' },
    ],
  },
  {
    id: 'g14',
    pattern: '-(으)ㄹ 수 있어요/없어요',
    meaning: '表示能力或可能性：“能够 / 不能……”',
    level: 'TOPIK I · 初级',
    category: '中高级表达',
    rule: '词干有收音接 -을 수 있어요；无收音接 -ㄹ 수 있어요。',
    stems: [
      { stem: '하다', stemMeaning: '做', conjugated: '할 수 있어요', roman: 'hal su isseoyo', fullSentence: '저는 한국어로 말할 수 있어요.', fullChinese: '我能用韩语说话。' },
      { stem: '가다', stemMeaning: '去', conjugated: '갈 수 없어요', roman: 'gal su eopseoyo', fullSentence: '오늘은 약속이 있어서 갈 수 없어요.', fullChinese: '今天有约，去不了。' },
    ],
  },
  {
    id: 'g15',
    pattern: '-아/어야 해요',
    meaning: '表示义务或必要性：“必须 / 应该……”',
    level: 'TOPIK II · 中级',
    category: '中高级表达',
    rule: '词干末音节元音为 ㅏ, ㅗ 接 -아야 해요；其他接 -어야 해요。',
    stems: [
      { stem: '가다', stemMeaning: '去', conjugated: '가야 해요', roman: 'gaya haeyo', fullSentence: '지금 바로 공항에 가야 해요.', fullChinese: '现在必须马上去机场。' },
      { stem: '쉬다', stemMeaning: '休息', conjugated: '쉬어야 해요', roman: 'swieoya haeyo', fullSentence: '몸이 안 좋으면 집에서 쉬어야 해요.', fullChinese: '身体不舒服的话应该在家休息。' },
    ],
  },
  {
    id: 'g16',
    pattern: '-아/어 보다',
    meaning: '表示尝试或经历：“试着……”',
    level: 'TOPIK II · 中级',
    category: '中高级表达',
    rule: '动词词干后接 -아/어 보다，常用于 -아/어 보세요（请试试）或 -아/어 봤어요（试过）。',
    stems: [
      { stem: '입다', stemMeaning: '穿', conjugated: '입어 보세요', roman: 'ibeo boseyo', fullSentence: '이 코트를 한 번 입어 보세요.', fullChinese: '请试穿一下这件大衣。' },
      { stem: '먹다', stemMeaning: '吃', conjugated: '먹어 봤어요', roman: 'meogeo bwasseoyo', fullSentence: '한국에서 삼겹살을 먹어 봤어요.', fullChinese: '在韩国吃过五花肉。' },
    ],
  },
  {
    id: 'g17',
    pattern: '-(으)ㄹ 것 같아요',
    meaning: '表示推测或委婉判断：“好像 / 似乎……”',
    level: 'TOPIK II · 中级',
    category: '中高级表达',
    rule: '动词现在时接 -는 것 같아요，将来/推测接 -(으)ㄹ 것 같아요。',
    stems: [
      { stem: '오다', stemMeaning: '来/下（雨）', conjugated: '올 것 같아요', roman: 'ol geot gatayo', fullSentence: '하늘을 보니 비가 올 것 같아요.', fullChinese: '看天空好像要下雨了。' },
      { stem: '좋다', stemMeaning: '好', conjugated: '좋을 것 같아요', roman: 'joeul geot gatayo', fullSentence: '이 선물이 정말 좋을 것 같아요.', fullChinese: '这个礼物好像真的很不错。' },
    ],
  },
];

export interface DialogueTurn {
  speaker: string;
  role: 'staff' | 'learner';
  korean: string;
  roman: string;
  chinese: string;
}

export interface DialogueScenario {
  id: string;
  title: string;
  location: string;
  level: string;
  turns: DialogueTurn[];
}

export const DIALOGUE_SCENARIOS: DialogueScenario[] = [
  {
    id: 'd1',
    title: '在首尔咖啡馆点单',
    location: '延南洞 · 咖啡馆',
    level: '初级实用',
    turns: [
      { speaker: '店员', role: 'staff', korean: '어서 오세요! 주문하시겠어요?', roman: 'eoseo oseyo! jumunhasigesseoyo?', chinese: '欢迎光临！请问要点单吗？' },
      { speaker: '你', role: 'learner', korean: '네, 아이스 아메리카노 한 잔 주세요.', roman: 'ne, aiseu amerikaeno han jan juseyo.', chinese: '好的，请给我一杯冰美式咖啡。' },
      { speaker: '店员', role: 'staff', korean: '매장에서 드시나요, 가져가시나요?', roman: 'maejangeseo deusinayo, gajyeogasinayo?', chinese: '请问是在店里喝，还是打包带走？' },
      { speaker: '你', role: 'learner', korean: '매장에서 마실게요. 감사합니다.', roman: 'maejangeseo masilgeyo. gamsahamnida.', chinese: '我在店里喝。谢谢。' },
    ],
  },
  {
    id: 'd2',
    title: '乘坐地铁问路',
    location: '弘大入口站 · 2号线',
    level: '初级实用',
    turns: [
      { speaker: '你', role: 'learner', korean: '실례지만, 2호선 타는 곳이 어디예요?', roman: 'sillyejiman, ihoseon taneun gosi eodiyeyo?', chinese: '打扰一下，请问2号线乘车处在哪里？' },
      { speaker: '路人', role: 'staff', korean: '저기 에스컬레이터로 내려가시면 돼요.', roman: 'jeogi eseukeolleiteoro naeryeogasimyeon dwaeyo.', chinese: '从那边坐自动扶梯下去就可以了。' },
      { speaker: '你', role: 'learner', korean: '아, 네! 정말 감사합니다.', roman: 'a, ne! jeongmal gamsahamnida.', chinese: '啊，好的！非常感谢。' },
    ],
  },
];

export interface KDramaLine {
  speaker: string;
  korean: string;
  roman: string;
  chinese: string;
}

export interface KDramaItem {
  id: string;
  titleCn: string;
  titleKr: string;
  year: string;
  genre: string;
  sceneTitle: string;
  lines: KDramaLine[];
}

export const KDRAMA_LIST: KDramaItem[] = [
  {
    id: 'kd1',
    titleCn: '眼泪女王',
    titleKr: '눈물의 여왕',
    year: '2024',
    genre: '浪漫 · 爱情',
    sceneTitle: '经典台词语录 (10句)',
    lines: [
      { speaker: '白贤祐', korean: '나는 언제나 네 편이야.', roman: 'naneun eonjena ne pyeoniya.', chinese: '我永远都是站在你这边的。' },
      { speaker: '洪海仁', korean: '그 말 진심이야? 후회 안 해?', roman: 'geu mal jinsimiya? huhoe an hae?', chinese: '那句话是真心的吗？不会后悔吗？' },
      { speaker: '白贤祐', korean: '절대 후회 안 해. 약속할게.', roman: 'jeoldae huhoe an hae. yaksokhalge.', chinese: '绝对不会后悔。我向你保证。' },
      { speaker: '洪海仁', korean: '내가 기억을 잃어도 나를 알아볼 수 있어?', roman: 'naega gieogeul ireodo nareul arabol su isseo?', chinese: '就算我失去记忆，你也能认出我吗？' },
      { speaker: '白贤祐', korean: '어떤 모습이어도 내가 먼저 찾아낼게.', roman: 'eotteon moseubieodo naega meonjeo chajanaelge.', chinese: '无论你是什么样子，我都会先找到你。' },
      { speaker: '洪海仁', korean: '당신과 함께한 모든 순간이 기적이었어.', roman: 'dangsingwa hamkkehan modeun sungani gijeogieosseo.', chinese: '和你在一起的每一刻都是奇迹。' },
      { speaker: '白贤祐', korean: '울지 마, 네가 울면 내 마음이 더 아파.', roman: 'ulji ma, nega ulmyeon nae maeumi deo apa.', chinese: '别哭，你哭的话我的心会更痛。' },
      { speaker: '洪海仁', korean: '다음 생에도 우리 꼭 다시 만나자.', roman: 'daeum saengedo uri kkok dasi mannaja.', chinese: '下辈子我们也一定要再见面。' },
      { speaker: '白贤祐', korean: '오늘도 내일도 나는 너만 사랑해.', roman: 'oneuldo naeildo naneun neoman saranghae.', chinese: '今天也好明天也好，我只爱你一个人。' },
      { speaker: '洪海仁', korean: '내 인생의 가장 큰 행운은 너야.', roman: 'nae insaengui gajang keun haenguneun neoya.', chinese: '我人生中最大的幸运就是你。' },
    ],
  },
  {
    id: 'kd2',
    titleCn: '背着善宰跑',
    titleKr: '선재 업고 튀어',
    year: '2024',
    genre: '奇幻 · 青春',
    sceneTitle: '经典台词语录 (10句)',
    lines: [
      { speaker: '柳善宰', korean: '네가 어떤 시간 속에 있든 내가 찾아갈게.', roman: 'nega eotteon sigan soge itdeun naega chajagalge.', chinese: '无论你在哪个时间里，我都会去找你。' },
      { speaker: '任率', korean: '선재야, 이번에는 내가 너를 지켜 줄게.', roman: 'seonjaeya, ibeoneneun naega neoreul jikyeo julge.', chinese: '善宰啊，这一次换我来守护你。' },
      { speaker: '柳善宰', korean: '오늘 살아갈 이유가 생겼어, 바로 너야.', roman: 'oneul saragal iyuga saenggyeosseo, baro neoya.', chinese: '今天我有了活下去的理由，那就是你。' },
      { speaker: '任率', korean: '네가 빛나는 모습을 계속 보고 싶어.', roman: 'nega binnaneun moseubeul gyesok bogo sipeo.', chinese: '我想一直看着你闪闪发光的样子。' },
      { speaker: '柳善宰', korean: '비가 오면 내가 우산이 되어 줄게.', roman: 'biga omyeon naega usani doeeo julge.', chinese: '如果下雨的话，我来当你的雨伞。' },
      { speaker: '任率', korean: '우리의 시간은 절대 멈추지 않을 거야.', roman: 'uriui siganeun jeoldae meomchuji aneul geoya.', chinese: '我们的时间绝对不会停止。' },
      { speaker: '柳善宰', korean: '처음 본 순간부터 너만 보였어.', roman: 'cheoeum bon sunganbuteo neoman boyeosseo.', chinese: '从第一眼见到你开始，我眼里就只有你。' },
      { speaker: '任率', korean: '고마워, 내 곁에 있어 줘서.', roman: 'gomawo, nae gyeote isseo jwoseo.', chinese: '谢谢你，一直陪在我身边。' },
      { speaker: '柳善宰', korean: '이제는 도망치지 말고 내 손을 잡아.', roman: 'ijeneun domangchiji malgo nae soneul jaba.', chinese: '现在不要再逃跑了，抓住我的手吧。' },
      { speaker: '任率', korean: '영원히 너를 응원할게, 선재야.', roman: 'yeongwonhi neoreul eungwonhalge, seonjaeya.', chinese: '我会永远为你加油的，善宰啊。' },
    ],
  },
  {
    id: 'kd3',
    titleCn: '鬼怪',
    titleKr: '도깨비',
    year: '2016',
    genre: '奇幻 · 经典',
    sceneTitle: '经典台词语录 (10句)',
    lines: [
      { speaker: '金信', korean: '너와 함께한 시간 모두 눈부셨다.', roman: 'neowa hamkkehan sigan modu nunbusyeotda.', chinese: '与你共度的所有时光都很耀眼。' },
      { speaker: '池恩倬', korean: '첫눈 오는 날에 꼭 다시 만나요.', roman: 'cheonnun oneun nare kkok dasi mannayo.', chinese: '下初雪的那天，我们一定要再见。' },
      { speaker: '金信', korean: '날이 좋아서, 날이 좋지 않아서, 날이 적당해서.', roman: 'nari joaseo, nari jochi anaseo, nari jeokdanghaeseo.', chinese: '因为天气好，因为天气不好，因为天气刚刚好。' },
      { speaker: '池恩倬', korean: '아저씨, 저는 아저씨의 신부예요.', roman: 'ajeossi, jeoneun ajeossiui sinbuyeyo.', chinese: '大叔，我是大叔的新娘。' },
      { speaker: '金信', korean: '너의 모든 생을 내가 지켜볼 거야.', roman: 'neoui modeun saengeul naega jikyeobol geoya.', chinese: '你的一生我都会守护着。' },
      { speaker: '池恩倬', korean: '사랑해요, 정말 많이 사랑해요.', roman: 'saranghaeyo, jeongmal mani saranghaeyo.', chinese: '我爱你，真的很爱你。' },
      { speaker: '金信', korean: '비로 오겠다, 첫눈으로 오겠다.', roman: 'biro ogetda, cheonnuneuro ogetda.', chinese: '我会化作雨而来，我会化作初雪而来。' },
      { speaker: '池恩倬', korean: '이젠 혼자 두지 마세요, 약속해요.', roman: 'ijen honja duji maseyo, yaksokaeyo.', chinese: '现在不要再留我一个人了，约定好。' },
      { speaker: '金信', korean: '네가 웃으면 세상도 같이 웃어.', roman: 'nega useumyeon sesangdo gachi useo.', chinese: '你一笑，世界也跟着笑了。' },
      { speaker: '池恩倬', korean: '우리의 인연은 끝이 아니라 시작이에요.', roman: 'uriui inyeoneun kkeuchi anira sijagieyo.', chinese: '我们的缘分不是结束，而是开始。' },
    ],
  },
  {
    id: 'kd4',
    titleCn: '黑暗荣耀',
    titleKr: '더 글로리',
    year: '2022',
    genre: '悬疑 · 复仇',
    sceneTitle: '经典台词语录 (10句)',
    lines: [
      { speaker: '文东恩', korean: '오늘부터 내 꿈은 너야, 박연진.', roman: 'oneulbuteo nae kkumeun neoya, bagyeonjin.', chinese: '从今天起，我的梦想就是你，朴妍珍。' },
      { speaker: '朱如炡', korean: '필요하면 언제든지 말씀하세요.', roman: 'piryohamyeon eonjedeunji malsseumhaseyo.', chinese: '如果需要的话，请随时告诉我。' },
      { speaker: '文东恩', korean: '용서는 없어, 그래서 영광도 없겠지.', roman: 'yongseoneun eopseo, geuraeseo yeonggwangdo eopgetji.', chinese: '没有原谅，所以也不会有荣耀吧。' },
      { speaker: '朱如炡', korean: '당신의 복수가 끝날 때까지 함께할게요.', roman: 'dangsinui boksuga kkeutnal ttaekkaji hamkkehalgeyo.', chinese: '直到你的复仇结束为止，我都会陪着你。' },
      { speaker: '文东恩', korean: '천천히, 아주 오랫동안 무너뜨릴 거야.', roman: 'cheoncheonhi, aju oraetdongan muneotteuril geoya.', chinese: '我会慢慢地、长久地摧毁你。' },
      { speaker: '朱如炡', korean: '이제는 조금 웃어도 괜찮아요.', roman: 'ijeneun jogeum useodo gwaenchanayo.', chinese: '现在稍微笑一笑也没关系的。' },
      { speaker: '文东恩', korean: '내가 여기까지 오는 데 얼마나 걸렸는지 알아?', roman: 'naega yeogikkaji oneun de eolmana geollyeonneunji ara?', chinese: '你知道我走到这里花了多长时间吗？' },
      { speaker: '朱如炡', korean: '당신은 혼자가 아니에요, 내가 있어요.', roman: 'dangsineun honjaga anieyo, naega isseoyo.', chinese: '你不是一个人，还有我在。' },
      { speaker: '文东恩', korean: '진실은 결국 드러나게 되어 있어.', roman: 'jinsireun gyeolguk deureonage doeeo isseo.', chinese: '真相最终一定会水落石出的。' },
      { speaker: '朱如炡', korean: '당신의 봄이 곧 올 거예요.', roman: 'dangsinui bomi got ol geoyeyo.', chinese: '你的春天很快就会到来的。' },
    ],
  },
  {
    id: 'kd5',
    titleCn: '爱的迫降',
    titleKr: '사랑의 불시착',
    year: '2019',
    genre: '浪漫 · 剧情',
    sceneTitle: '经典台词语录 (10句)',
    lines: [
      { speaker: '利正赫', korean: '우연이 아니라 운명인 것 같소.', roman: 'uyeoni anira unmyeongin geot gatso.', chinese: '看来不是偶然，而是命运。' },
      { speaker: '尹世理', korean: '나도 같은 생각이에요. 정말 고마워요.', roman: 'nado gateun saenggagieyo. jeongmal gomawoyo.', chinese: '我也是这么想的。真的很感谢你。' },
      { speaker: '利正赫', korean: '내 시야에 있는 한 당신은 안전할 거요.', roman: 'nae siyae inneun han dangsineun anjeonhal geoyo.', chinese: '只要在我的视线范围内，你就是安全的。' },
      { speaker: '尹世理', korean: '당신을 만난 건 내 인생 최고의 선물이었어요.', roman: 'dangsineul mannan geon nae insaeng choegoui seonmurieosseoyo.', chinese: '遇到你是我人生中最好的礼物。' },
      { speaker: '利正赫', korean: '기다리고 있겠소, 언제까지나.', roman: 'gidarigo itgetso, eonjekkajina.', chinese: '我会一直等下去，无论多久。' },
      { speaker: '尹世理', korean: '우리 꼭 다시 만날 수 있을 거예요.', roman: 'uri kkok dasi mannal su isseul geoyeyo.', chinese: '我们一定能再次见面的。' },
      { speaker: '利正赫', korean: '당신이 어디에 있든 내가 찾아가겠소.', roman: 'dangsini eodie itdeun naega chajagagetso.', chinese: '无论你在哪里，我都会去找你。' },
      { speaker: '尹世理', korean: '오늘따라 당신이 너무 보고 싶어요.', roman: 'oneulttara dangsini neomu bogo sipeoyo.', chinese: '今天格外想念你。' },
      { speaker: '利正赫', korean: '아프지 말고 건강하게 잘 지내시오.', roman: 'apeuji malgo geonganghage jal jinaesio.', chinese: '不要生病，要健健康康地好好生活。' },
      { speaker: '尹世理', korean: '사랑해요, 리정혁 씨.', roman: 'saranghaeyo, rijeonghyeok ssi.', chinese: '我爱你，利正赫先生。' },
    ],
  },
  {
    id: 'kd6',
    titleCn: '请回答1988',
    titleKr: '응답하라 1988',
    year: '2015',
    genre: '家庭 · 治愈',
    sceneTitle: '经典台词语录 (10句)',
    lines: [
      { speaker: '成德善', korean: '오늘 저녁에 우리 집에서 같이 밥 먹자!', roman: 'oneul jeonyeoge uri jibeseo gachi bap meokja!', chinese: '今天晚上来我家一起吃饭吧！' },
      { speaker: '崔泽', korean: '응, 알겠어. 금방 갈게.', roman: 'eung, algesseo. geumbang galge.', chinese: '嗯，知道了。我马上过去。' },
      { speaker: '成德善', korean: '우리가 함께 보낸 청춘이 너무 그리워.', roman: 'uriga hamkke bonaen cheongchuni neomu geuriwo.', chinese: '好怀念我们一起度过的青春啊。' },
      { speaker: '崔泽', korean: '네가 웃으면 나도 기분이 좋아져.', roman: 'nega useumyeon nado gibuni joajyeo.', chinese: '你一笑，我的心情也会变好。' },
      { speaker: '成德善', korean: '힘들 때는 언제든지 내 어깨에 기대.', roman: 'himdeul ttaeneun eonjedeunji nae eokkaee gidae.', chinese: '累的时候随时靠在我的肩膀上吧。' },
      { speaker: '崔泽', korean: '나는 너만 있으면 아무것도 필요 없어.', roman: 'naneun neoman isseumyeon amugeotdo piryo eopseo.', chinese: '只要有你，我什么都不需要。' },
      { speaker: '成德善', korean: '우리 우정은 영원히 변하지 않을 거야.', roman: 'uri ujeongeun yeongwonhi byeonhaji aneul geoya.', chinese: '我们的友情永远不会改变。' },
      { speaker: '崔泽', korean: '오늘 밤은 별이 정말 많이 떴네.', roman: 'oneul bameun byeori jeongmal mani tteonne.', chinese: '今晚的星星真多啊。' },
      { speaker: '成德善', korean: '내일 아침에 같이 학교 가자!', roman: 'naeil achime gachi hakgyo gaja!', chinese: '明天早上一起去学校吧！' },
      { speaker: '崔泽', korean: '응, 내가 집 앞에서 기다릴게.', roman: 'eung, naega jip apeseo gidarilge.', chinese: '嗯，我在家门口等你。' },
    ],
  },
];

export const KOREAN_WORD_GLOSSARY: Record<string, string> = {
  '안녕하세요': '您好',
  '만나서': '见到',
  '반갑습니다': '很高兴',
  '도와주셔서': '感谢帮助',
  '정말': '真的',
  '감사합니다': '非常感谢',
  '늦어서': '因为迟到了',
  '죄송합니다': '对不起',
  '천천히': '慢慢地',
  '하셔도': '即使做',
  '괜찮아요': '没关系',
  '어서': '快',
  '오세요': '请进/来',
  '주문하시겠어요': '请问要点单吗',
  '네': '是的',
  '아이스': '冰',
  '아메리카노': '美式咖啡',
  '한': '一',
  '잔': '杯',
  '주세요': '请给我',
  '매장에서': '在店里',
  '드시나요': '请问要吃/喝吗',
  '가져가시나요': '请问要打包带走吗',
  '마실게요': '我喝',
  '실례지만': '打扰一下',
  '2호선': '2号线',
  '타는': '乘坐的',
  '곳이': '地方',
  '어디예요': '在哪里',
  '저기': '那里',
  '에스컬레이터로': '坐自动扶梯',
  '내려가시면': '下去的话',
  '돼요': '就可以了',
  '아': '啊',
  '저는': '我',
  '오늘': '今天',
  '서울에': '去首尔',
  '가요': '去',
  '점심에': '午饭时',
  '비빔밥을': '拌饭',
  '먹어요': '吃',
  '매일': '每天',
  '한국어를': '韩语',
  '공부해요': '学习',
  '한국': '韩国',
  '영화를': '电影',
  '보고': '看',
  '싶어요': '想',
  '시원한': '冰爽的',
  '커피를': '咖啡',
  '제주도에': '去济州岛',
  '여행하고': '旅行',
  '물': '水',
  '잔만': '只一杯',
  '여기': '这里',
  '메뉴판을': '菜单',
  '따뜻한': '热的',
  '나는': '我',
  '언제나': '无论何时',
  '편이야': '一边/阵营',
  '그': '那',
  '말': '话',
  '진심이야': '是真心的吗',
  '후회': '后悔',
  '안': '不',
  '해': '做',
  '절대': '绝对',
  '약속할게': '我保证',
  '네가': '你',
  '어떤': '无论什么',
  '시간': '时间',
  '속에': '里面',
  '있든': '无论在',
  '내가': '我',
  '찾아갈게': '会去找你',
  '선재야': '善宰啊',
  '이번에는': '这一次',
  '너를': '你',
  '지켜': '守护',
  '줄게': '给你',
  '너와': '与你',
  '함께한': '共度的',
  '모두': '全都',
  '눈부셨다': '很耀眼',
  '첫눈': '初雪',
  '오는': '来的',
  '날에': '日子里',
  '꼭': '一定',
  '다시': '再次',
  '만나요': '见面吧',
  '오늘부터': '从今天起',
  '내': '我的',
  '꿈은': '梦想是',
  '너야': '就是你',
  '박연진': '朴妍珍',
  '필요하면': '如果需要',
  '언제든지': '随时',
  '말씀하세요': '请说',
  '우연이': '偶然',
  '아니라': '不是',
  '운명인': '是命运',
  '것': '事情',
  '같소': '好像',
  '나도': '我也',
  '같은': '相同的',
  '생각이에요': '想法',
  '고마워요': '谢谢',
  '저녁에': '晚上',
  '우리': '我们',
  '집에서': '在家里',
  '같이': '一起',
  '밥': '饭',
  '먹자': '吃吧',
  '응': '嗯',
  '알겠어': '知道了',
  '금방': '马上',
  '갈게': '过去',
};

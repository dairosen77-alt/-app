import React, { useState } from 'react';
import { BookOpen, Layers, Sparkles, MessageSquare, Film, Languages, SlidersHorizontal } from 'lucide-react';
import { HangulLab } from './components/HangulLab';
import { VocabularyDeck } from './components/VocabularyDeck';
import { GrammarStudio } from './components/GrammarStudio';
import { DialoguePractice } from './components/DialoguePractice';
import { KDramaStudio } from './components/KDramaStudio';
import { TranslatorStudio } from './components/TranslatorStudio';
import { VoiceSettingsModal } from './components/VoiceSettingsModal';

type SectionId = 'hangul' | 'vocab' | 'grammar' | 'dialogue' | 'kdrama' | 'translate';

const NAV_ITEMS: { id: SectionId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'hangul', label: '字母', icon: Sparkles },
  { id: 'vocab', label: '词库', icon: Layers },
  { id: 'grammar', label: '语法', icon: BookOpen },
  { id: 'dialogue', label: '对话', icon: MessageSquare },
  { id: 'kdrama', label: '韩剧', icon: Film },
  { id: 'translate', label: '翻译', icon: Languages },
];

export default function App() {
  const [activeSection, setActiveSection] = useState<SectionId>('vocab');
  const [masteredIds, setMasteredIds] = useState<Record<string, boolean>>({});
  const [isVoiceSettingsOpen, setIsVoiceSettingsOpen] = useState<boolean>(false);

  const masteredCount = Object.values(masteredIds).filter(Boolean).length;

  const handleToggleMastered = (id: string) => {
    setMasteredIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="h-[100dvh] w-full max-w-lg mx-auto flex flex-col bg-[#F8FAFC] text-[#0F172A] overflow-hidden border-x border-slate-200/80">
      {/* Fixed Top Bar: App Name + Basic Learning Stats */}
      <header className="shrink-0 bg-white border-b border-slate-200 px-4 h-12 flex items-center justify-between gap-4">
        <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
          한글 · 韩语研习社
        </span>

        <div className="flex items-center gap-2.5 text-xs text-slate-600 font-mono-code whitespace-nowrap shrink-0">
          <span>已掌握 {masteredCount}/10000</span>
          <button
            type="button"
            onClick={() => setIsVoiceSettingsOpen(true)}
            className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-slate-100 hover:bg-sky-50 text-slate-700 hover:text-sky-700 font-sans font-medium transition-colors"
            title="语音设置"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>语音</span>
          </button>
        </div>
      </header>

      {/* Main Single-Screen Workspace */}
      <main className="flex-1 min-h-0 px-3.5 py-2.5 overflow-y-auto">
        {activeSection === 'hangul' && <HangulLab />}
        {activeSection === 'vocab' && (
          <VocabularyDeck masteredIds={masteredIds} onToggleMastered={handleToggleMastered} />
        )}
        {activeSection === 'grammar' && <GrammarStudio />}
        {activeSection === 'dialogue' && <DialoguePractice />}
        {activeSection === 'kdrama' && <KDramaStudio />}
        {activeSection === 'translate' && <TranslatorStudio />}
      </main>

      {/* Fixed Bottom Navigation Bar */}
      <nav
        aria-label="主导航"
        className="shrink-0 bg-white border-t border-slate-200 px-1 py-1.5 grid grid-cols-6 gap-0.5"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeSection === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveSection(item.id)}
              className={`flex flex-col items-center justify-center py-1 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                isActive ? 'text-sky-700 bg-sky-50 font-semibold' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-[11px] mt-0.5 leading-none">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <VoiceSettingsModal
        isOpen={isVoiceSettingsOpen}
        onClose={() => setIsVoiceSettingsOpen(false)}
      />
    </div>
  );
}

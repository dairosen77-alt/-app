export type VoiceRoleId = 'female_a' | 'female_b' | 'male_a' | 'male_b';
export type SpeechMode = 'standard' | 'drama';
export type VoiceGender = 'male' | 'female';

export interface VoiceSettings {
  roleId: VoiceRoleId;
  mode: SpeechMode;
  rate: number;
  loopSingle: boolean;
  useSystemFallback: boolean;
}

export const VOICE_ROLE_OPTIONS: Array<{
  id: VoiceRoleId;
  label: string;
  gender: VoiceGender;
  desc: string;
}> = [
  { id: 'female_a', label: '女声 A · 金泰梨风格（温柔清甜）', gender: 'female', desc: '温柔、清甜、自然，适合日常生活及情感对话' },
  { id: 'female_b', label: '女声 B · 活泼甜美型', gender: 'female', desc: '清新、明亮、自然，适合年轻人日常交流' },
  { id: 'male_a', label: '男声 A · 朴宝剑风格（温柔清澈）', gender: 'male', desc: '沉稳、温暖、清澈，适合韩剧男主角日常交流' },
  { id: 'male_b', label: '男声 B · 阳光温暖型', gender: 'male', desc: '轻松、亲切、自然，适合朋友和生活场景对话' },
];

const SETTINGS_STORAGE_KEY = 'korean_app_voice_settings_v1';

let currentSettings: VoiceSettings = (() => {
  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (saved) {
        return {
          roleId: 'female_a',
          mode: 'standard',
          rate: 0.9,
          loopSingle: false,
          useSystemFallback: true,
          ...JSON.parse(saved),
        };
      }
    } catch {
      // Ignore storage errors
    }
  }
  return {
    roleId: 'female_a',
    mode: 'standard',
    rate: 0.9,
    loopSingle: false,
    useSystemFallback: true,
  };
})();

export function getVoiceSettings(): VoiceSettings {
  return currentSettings;
}

export function updateVoiceSettings(patch: Partial<VoiceSettings>): VoiceSettings {
  currentSettings = { ...currentSettings, ...patch };
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(currentSettings));
    } catch {
      // Ignore storage errors
    }
  }
  return currentSettings;
}

const audioUrlCache = new Map<string, string>();
const audioProviderCache = new Map<string, string>();
let currentAudio: HTMLAudioElement | null = null;
let activeSentenceText: string | null = null;

type WordProgressListener = (activeWordIndex: number | null) => void;
const wordListeners = new Map<string, Set<WordProgressListener>>();

export function subscribeWordProgress(sentence: string, listener: WordProgressListener): () => void {
  const key = sentence.trim();
  if (!wordListeners.has(key)) {
    wordListeners.set(key, new Set());
  }
  wordListeners.get(key)!.add(listener);
  return () => {
    wordListeners.get(key)?.delete(listener);
  };
}

function notifyWordProgress(sentence: string, index: number | null) {
  const key = sentence.trim();
  wordListeners.get(key)?.forEach((fn) => fn(index));
}

export function stopKoreanAudio(): void {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.currentTime = 0;
    currentAudio = null;
  }
  if (activeSentenceText) {
    notifyWordProgress(activeSentenceText, null);
    activeSentenceText = null;
  }
  wordListeners.forEach((set) => set.forEach((fn) => fn(null)));
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // Ignore
    }
  }
}

function fallbackSpeechSynthesis(text: string, rate: number, gender: VoiceGender): void {
  if (!currentSettings.useSystemFallback) return;
  if ('speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ko-KR';
      utterance.rate = rate;
      utterance.pitch = gender === 'male' ? 0.9 : 1.08;

      const voices = window.speechSynthesis.getVoices();
      const koVoices = voices.filter((v) => v.lang.startsWith('ko'));
      if (koVoices.length > 0) {
        const preferred =
          gender === 'male'
            ? koVoices.find((v) => /male|man|minho|joon|hyun/i.test(v.name)) || koVoices[0]
            : koVoices.find((v) => /female|woman|yuna|sora|jiyeon|heami/i.test(v.name)) || koVoices[0];
        utterance.voice = preferred;
      }

      window.speechSynthesis.speak(utterance);
    } catch {
      // Ignore fallback errors
    }
  }
}

async function getCachedBlob(cacheKey: string): Promise<Blob | null> {
  if (typeof window === 'undefined' || !('caches' in window)) return null;
  try {
    const cache = await caches.open('korean-tts-v1');
    const match = await cache.match(`https://tts.local/${encodeURIComponent(cacheKey)}`);
    if (match) {
      return await match.blob();
    }
  } catch {
    // Ignore Cache API errors
  }
  return null;
}

async function putCachedBlob(cacheKey: string, blob: Blob): Promise<void> {
  if (typeof window === 'undefined' || !('caches' in window)) return;
  try {
    const cache = await caches.open('korean-tts-v1');
    await cache.put(
      `https://tts.local/${encodeURIComponent(cacheKey)}`,
      new Response(blob, { headers: { 'Content-Type': blob.type || 'audio/mpeg' } })
    );
  } catch {
    // Ignore Cache API errors
  }
}

export async function speakKorean(
  text: string,
  customRate?: number,
  customGenderOrRole?: VoiceGender | VoiceRoleId
): Promise<void> {
  if (typeof window === 'undefined') return;
  const cleanText = text.trim();
  if (!cleanText) return;

  stopKoreanAudio();

  const settings = currentSettings;
  const rate = typeof customRate === 'number' ? customRate : settings.rate;

  let roleId: VoiceRoleId = settings.roleId;
  if (customGenderOrRole === 'male') {
    roleId = settings.roleId.startsWith('male') ? settings.roleId : 'male_a';
  } else if (customGenderOrRole === 'female') {
    roleId = settings.roleId.startsWith('female') ? settings.roleId : 'female_a';
  } else if (customGenderOrRole) {
    roleId = customGenderOrRole;
  }

  const gender: VoiceGender = roleId.startsWith('male') ? 'male' : 'female';
  const cacheKey = `${roleId}:${settings.mode}:${rate}:${cleanText}`;

  try {
    let audioUrl = audioUrlCache.get(cacheKey);

    if (!audioUrl) {
      let blob = await getCachedBlob(cacheKey);

      if (!blob) {
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: cleanText,
            roleId,
            mode: settings.mode,
            rate,
          }),
        });

        if (!res.ok) {
          throw new Error('TTS API failed');
        }

        const provider = res.headers.get('X-TTS-Provider') || '';
        audioProviderCache.set(cacheKey, provider);
        blob = await res.blob();
        await putCachedBlob(cacheKey, blob);
      }

      audioUrl = URL.createObjectURL(blob);
      if (audioUrlCache.size > 120) {
        const firstKey = audioUrlCache.keys().next().value;
        if (firstKey) {
          const oldUrl = audioUrlCache.get(firstKey);
          if (oldUrl) URL.revokeObjectURL(oldUrl);
          audioUrlCache.delete(firstKey);
        }
      }
      audioUrlCache.set(cacheKey, audioUrl);
    }

    const audio = new Audio(audioUrl);
    audio.playbackRate = rate;
    activeSentenceText = cleanText;

    const tokens = cleanText.split(/\s+/);
    if (tokens.length > 1) {
      const weights = tokens.map((t) => {
        const base = Math.max(1, t.replace(/[.,!?~"'()]/g, '').length);
        const pause = /[,，]/.test(t) ? 1.8 : /[.!?。！？]/.test(t) ? 2.4 : 0;
        return base + pause;
      });
      const totalWeight = weights.reduce((a, b) => a + b, 0);

      audio.addEventListener('timeupdate', () => {
        if (!audio.duration || isNaN(audio.duration) || activeSentenceText !== cleanText) return;
        const rawProgress = audio.currentTime / audio.duration;
        const adjusted = Math.min(1, Math.max(0, (rawProgress - 0.05) / 0.9));
        let acc = 0;
        for (let i = 0; i < weights.length; i++) {
          acc += weights[i] / totalWeight;
          if (adjusted <= acc) {
            notifyWordProgress(cleanText, i);
            break;
          }
        }
      });
    }

    audio.addEventListener('ended', () => {
      if (activeSentenceText === cleanText) {
        notifyWordProgress(cleanText, null);
        activeSentenceText = null;
      }
    });

    audio.loop = settings.loopSingle;
    currentAudio = audio;
    await audio.play();
  } catch {
    fallbackSpeechSynthesis(cleanText, rate, gender);
  }
}

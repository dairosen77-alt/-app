import React, { useState, useMemo } from 'react';
import { Volume2, ArrowRight } from 'lucide-react';
import { GRAMMAR_PATTERNS } from '../data/koreanData';
import { speakKorean } from '../utils/speech';
import { InteractiveSentence } from './InteractiveSentence';

const GRAMMAR_CATEGORIES = ['全部', '入门基础', '时态与否定', '连接与因果', '中高级表达'] as const;

export const GrammarStudio: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('全部');
  const [selectedPatternId, setSelectedPatternId] = useState<string>(GRAMMAR_PATTERNS[0].id);
  const [selectedStemIdx, setSelectedStemIdx] = useState<number>(0);

  const filteredPatterns = useMemo(() => {
    if (selectedCategory === '全部') return GRAMMAR_PATTERNS;
    return GRAMMAR_PATTERNS.filter((g) => g.category === selectedCategory);
  }, [selectedCategory]);

  const currentPattern =
    filteredPatterns.find((g) => g.id === selectedPatternId) || filteredPatterns[0] || GRAMMAR_PATTERNS[0];
  const currentStem = currentPattern.stems[selectedStemIdx] || currentPattern.stems[0];

  return (
    <div className="flex flex-col gap-3 h-full overflow-y-auto pr-0.5">
      {/* Directory Category Selector */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 space-y-2.5 shrink-0">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900">韩语语法目录 ({filteredPatterns.length})</h2>
          <span className="text-xs text-slate-500">{currentPattern.level}</span>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
          {GRAMMAR_CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => {
                setSelectedCategory(cat);
                const nextList = cat === '全部' ? GRAMMAR_PATTERNS : GRAMMAR_PATTERNS.filter((g) => g.category === cat);
                if (nextList[0]) {
                  setSelectedPatternId(nextList[0].id);
                  setSelectedStemIdx(0);
                }
              }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Pattern Pills/Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1">
          {filteredPatterns.map((item) => {
            const isActive = item.id === currentPattern.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setSelectedPatternId(item.id);
                  setSelectedStemIdx(0);
                }}
                className={`px-3 py-1.5 rounded-lg border text-xs font-kr font-bold transition-all whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-sky-50 border-sky-600 text-sky-900'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-white'
                }`}
              >
                {item.pattern}
              </button>
            );
          })}
        </div>
      </div>

      {/* Interactive Conjugation & Sentence Builder */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="pb-3 border-b border-slate-100">
            <h3 className="font-kr text-lg font-bold text-slate-900">
              {currentPattern.pattern}{' '}
              <span className="text-sm font-normal text-slate-600">· {currentPattern.meaning}</span>
            </h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">{currentPattern.rule}</p>
          </div>

          {/* Stem Selector */}
          <div className="mt-3">
            <label className="block text-xs font-medium text-slate-700 mb-1.5">选择词干动态变形：</label>
            <div className="flex flex-wrap gap-1.5">
              {currentPattern.stems.map((s, idx) => (
                <button
                  key={s.stem}
                  type="button"
                  onClick={() => {
                    setSelectedStemIdx(idx);
                    speakKorean(s.fullSentence);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                    selectedStemIdx === idx
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-white'
                  }`}
                >
                  <span className="font-kr font-bold">{s.stem}</span>
                  <span className="opacity-75 ml-1">({s.stemMeaning})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Conjugation Transformation Box */}
          <div className="mt-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
              <span className="font-kr text-sm font-semibold text-slate-800">{currentStem.stem}</span>
              <span>+</span>
              <span className="font-kr text-sm font-semibold text-sky-700">{currentPattern.pattern}</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-kr text-base font-bold text-slate-900">{currentStem.conjugated}</span>
              <span className="font-mono-code text-[11px] text-slate-500">[{currentStem.roman}]</span>
            </div>

            <div className="mt-3 pt-3 border-t border-slate-200 flex items-start justify-between gap-2">
              <div>
                <div className="text-[11px] text-slate-500">完整例句（点击词汇发音 · 长按查词）</div>
                <InteractiveSentence sentence={currentStem.fullSentence} className="text-base font-bold mt-1" />
                <div className="text-xs text-slate-600 mt-1">{currentStem.fullChinese}</div>
              </div>
              <button
                type="button"
                onClick={() => speakKorean(currentStem.fullSentence)}
                className="p-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white transition-colors shrink-0"
                title="朗读例句"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Search, Play, Pause, SkipBack, SkipForward, Volume2 } from 'lucide-react';
import { KDRAMA_LIST, KDramaItem } from '../data/koreanData';
import { generateKDramaSentences } from '../data/expandedCorpus';
import { speakKorean, VoiceGender } from '../utils/speech';
import { InteractiveSentence } from './InteractiveSentence';

const MALE_CHARACTERS = new Set(['白贤祐', '柳善宰', '金信', '朱如炡', '利正赫', '崔泽']);
function getSpeakerGender(speaker: string): VoiceGender {
  return MALE_CHARACTERS.has(speaker) ? 'male' : 'female';
}

export const KDramaStudio: React.FC = () => {
  const allDramaSentences = useMemo(() => generateKDramaSentences(1000), []);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sentenceSearch, setSentenceSearch] = useState<string>('');
  const [sentencePage, setSentencePage] = useState<number>(0);
  const [selectedDrama, setSelectedDrama] = useState<KDramaItem>(KDRAMA_LIST[0]);
  const [activeLineIdx, setActiveLineIdx] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const timerRef = useRef<number | null>(null);

  const filteredSentences = useMemo(() => {
    const q = sentenceSearch.trim().toLowerCase();
    if (!q) return allDramaSentences;
    return allDramaSentences.filter(
      (s) =>
        s.korean.toLowerCase().includes(q) ||
        s.chinese.toLowerCase().includes(q) ||
        s.drama.toLowerCase().includes(q)
    );
  }, [allDramaSentences, sentenceSearch]);

  const sentencePageSize = 20;
  const totalSentencePages = Math.max(1, Math.ceil(filteredSentences.length / sentencePageSize));
  const pagedSentences = filteredSentences.slice(
    sentencePage * sentencePageSize,
    (sentencePage + 1) * sentencePageSize
  );

  const filteredDramas = KDRAMA_LIST.filter(
    (d) =>
      d.titleCn.toLowerCase().includes(searchQuery.trim().toLowerCase()) ||
      d.titleKr.toLowerCase().includes(searchQuery.trim().toLowerCase()) ||
      d.genre.toLowerCase().includes(searchQuery.trim().toLowerCase())
  );

  useEffect(() => {
    if (!isPlaying) {
      if (timerRef.current) window.clearTimeout(timerRef.current);
      return;
    }

    const currentLine = selectedDrama.lines[activeLineIdx];
    if (currentLine) {
      speakKorean(currentLine.korean, 0.95, getSpeakerGender(currentLine.speaker));
    }

    timerRef.current = window.setTimeout(() => {
      if (activeLineIdx < selectedDrama.lines.length - 1) {
        setActiveLineIdx((prev) => prev + 1);
      } else {
        setIsPlaying(false);
        setActiveLineIdx(0);
      }
    }, 3600);

    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, [isPlaying, activeLineIdx, selectedDrama]);

  const handleSelectDrama = (drama: KDramaItem) => {
    setIsPlaying(false);
    setSelectedDrama(drama);
    setActiveLineIdx(0);
  };

  const [liveResults, setLiveResults] = useState<
    Array<{
      id: string;
      name: string;
      premiered: string;
      genres: string[];
      officialSite: string;
      image: string;
      summary: string;
    }>
  >([]);
  const [isSearchingLive, setIsSearchingLive] = useState(false);

  const handleLiveSearch = async () => {
    const q = searchQuery.trim();
    if (!q) return;
    setIsSearchingLive(true);
    try {
      const res = await fetch(`/api/kdrama/search?q=${encodeURIComponent(q)}`);
      if (res.ok) {
        setLiveResults(await res.json());
      }
    } finally {
      setIsSearchingLive(false);
    }
  };

  return (
    <div className="flex flex-col gap-3 h-full overflow-y-auto pr-0.5">
      {/* Top Dropdown Selector & Live K-Drama Resource Search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 space-y-2.5 shrink-0">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-base font-semibold text-slate-900">韩剧精听 · 经典台词</h2>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleLiveSearch();
            }}
            className="flex items-center gap-1"
          >
            <div className="relative w-36 sm:w-44">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="搜索全网韩剧..."
                className="w-full pl-8 pr-2 py-1 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-sky-600"
              />
            </div>
            <button
              type="submit"
              disabled={isSearchingLive}
              className="px-2.5 py-1 text-xs font-medium bg-slate-900 text-white rounded-lg hover:bg-slate-800 disabled:opacity-50 shrink-0"
            >
              {isSearchingLive ? '搜索中' : '搜索'}
            </button>
          </form>
        </div>

        {/* Dropdown Selector for K-Dramas (10 lines each) */}
        <div className="flex items-center gap-2">
          <select
            value={selectedDrama.id}
            onChange={(e) => {
              const found = KDRAMA_LIST.find((d) => d.id === e.target.value);
              if (found) handleSelectDrama(found);
            }}
            aria-label="选择韩剧"
            className="w-full px-2.5 py-1.5 text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:border-sky-600"
          >
            {KDRAMA_LIST.map((drama) => (
              <option key={drama.id} value={drama.id}>
                《{drama.titleCn}》({drama.titleKr}) · {drama.lines.length}句经典台词
              </option>
            ))}
          </select>
        </div>

        {/* Live K-Drama Search Results */}
        {liveResults.length > 0 && (
          <div className="pt-2 border-t border-slate-100 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>全网韩剧资源搜索结果 ({liveResults.length})</span>
              <button
                type="button"
                onClick={() => setLiveResults([])}
                className="text-sky-600 hover:underline"
              >
                收起
              </button>
            </div>
            <div className="grid grid-cols-1 gap-2 max-h-44 overflow-y-auto">
              {liveResults.map((item) => (
                <div
                  key={item.id}
                  className="p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {item.image && (
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-9 h-12 object-cover rounded shrink-0"
                      />
                    )}
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-900 truncate">{item.name}</div>
                      <div className="text-[11px] text-slate-500">
                        {item.premiered || '韩剧'} · {item.genres.join(', ') || '剧情'}
                      </div>
                    </div>
                  </div>
                  {item.officialSite && (
                    <a
                      href={item.officialSite}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 text-[11px] font-medium bg-sky-600 text-white rounded-md hover:bg-sky-700 shrink-0"
                    >
                      官方正片
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Interactive K-Drama Scene Player with HD Video Clip */}
      <div className="bg-slate-900 text-white border border-slate-800 rounded-xl p-4 space-y-3 shrink-0">
        <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
          <div>
            <div className="text-[11px] text-sky-400">
              {selectedDrama.titleCn} ({selectedDrama.titleKr}) · {selectedDrama.year}
            </div>
            <h3 className="text-sm font-semibold text-white">{selectedDrama.sceneTitle}</h3>
          </div>

          {/* Playback Controls */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                setIsPlaying(false);
                setActiveLineIdx((prev) => (prev === 0 ? selectedDrama.lines.length - 1 : prev - 1));
              }}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
              title="上一句"
            >
              <SkipBack className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => setIsPlaying((p) => !p)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-medium transition-colors"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isPlaying ? '暂停' : '播放台词'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setIsPlaying(false);
                setActiveLineIdx((prev) => (prev === selectedDrama.lines.length - 1 ? 0 : prev + 1));
              }}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
              title="下一句"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Embedded HD K-Drama Video Clip */}
        <div className="w-full aspect-video rounded-lg overflow-hidden bg-black border border-slate-800">
          <iframe
            className="w-full h-full"
            src={`https://www.youtube.com/embed/${
              selectedDrama.id === 'kd1'
                ? 'Gg2D8zrzlOA'
                : selectedDrama.id === 'kd2'
                ? '5P8x3y4zK2w'
                : selectedDrama.id === 'kd3'
                ? '8z9kL2mN4pQ'
                : selectedDrama.id === 'kd4'
                ? 'tqVVrTvrI8U'
                : selectedDrama.id === 'kd5'
                ? 'eXMjTXL2Vks'
                : 'c-2_2_2_2_2'
            }?rel=0&modestbranding=1`}
            title={`${selectedDrama.titleCn} 高清片段`}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>

        {/* Synchronized Subtitle Lines */}
        <div className="space-y-3">
          {selectedDrama.lines.map((line, idx) => {
            const isActive = idx === activeLineIdx;
            return (
              <div
                key={idx}
                onClick={() => {
                  setActiveLineIdx(idx);
                  speakKorean(line.korean);
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  isActive
                    ? 'bg-slate-800/90 border-sky-500'
                    : 'bg-slate-900/50 border-slate-800 hover:border-slate-700 opacity-75'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                  <span className="font-medium text-sky-400">{line.speaker}</span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveLineIdx(idx);
                      speakKorean(line.korean);
                    }}
                    className="inline-flex items-center gap-1 text-xs text-slate-300 hover:text-white"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>朗读</span>
                  </button>
                </div>

                <div onClick={(e) => e.stopPropagation()}>
                  <InteractiveSentence sentence={line.korean} dark className="text-lg sm:text-xl font-semibold" />
                </div>

                <div className="font-mono-code text-xs text-sky-300/90 mt-1.5">{line.roman}</div>
                <div className="text-sm text-slate-300 mt-1">{line.chinese}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 1000 K-Drama Daily Expression Sentences Library */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-lg font-semibold text-slate-900">
              韩剧日常表达 1000 句精粹 ({filteredSentences.length} 句)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              全部取材自热门韩剧日常对话；点击任意词汇可单独发音，长按词汇可查看中文翻译
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={sentenceSearch}
              onChange={(e) => {
                setSentenceSearch(e.target.value);
                setSentencePage(0);
              }}
              placeholder="搜索台词、中文或剧名..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-sky-600"
            />
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {pagedSentences.map((item) => (
            <div key={item.id} className="py-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span className="font-medium text-sky-700">《{item.drama}》</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.category}</span>
                </div>
                <InteractiveSentence sentence={item.korean} className="text-base font-semibold" />
                <div className="text-sm text-slate-600">{item.chinese}</div>
              </div>

              <button
                type="button"
                onClick={() => speakKorean(item.korean)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-lg transition-colors shrink-0"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>朗读整句</span>
              </button>
            </div>
          ))}
        </div>

        <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-mono-code">
          <button
            type="button"
            disabled={sentencePage === 0}
            onClick={() => setSentencePage((p) => Math.max(0, p - 1))}
            className="px-3 py-1.5 rounded-lg border border-slate-200 disabled:opacity-40 hover:bg-slate-50"
          >
            上一页
          </button>
          <span>
            第 {sentencePage + 1} / {totalSentencePages} 页
          </span>
          <button
            type="button"
            disabled={sentencePage >= totalSentencePages - 1}
            onClick={() => setSentencePage((p) => Math.min(totalSentencePages - 1, p + 1))}
            className="px-3 py-1.5 rounded-lg border border-slate-200 disabled:opacity-40 hover:bg-slate-50"
          >
            下一页
          </button>
        </div>
      </div>
    </div>
  );
};

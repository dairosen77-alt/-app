import React, { useState, useMemo } from 'react';
import { Volume2, ChevronLeft, ChevronRight, Eye, EyeOff, Check, Search } from 'lucide-react';
import { VOCABULARY_LIST, VocabItem } from '../data/koreanData';
import { generateExpandedVocabulary } from '../data/expandedCorpus';
import { speakKorean } from '../utils/speech';
import { InteractiveSentence } from './InteractiveSentence';

const CATEGORIES = ['全部', '日常问候', '咖啡与美食', '交通出行', '购物数字', '情感表达', '韩剧高频'] as const;

interface VocabularyDeckProps {
  masteredIds: Record<string, boolean>;
  onToggleMastered: (id: string) => void;
}

export const VocabularyDeck: React.FC<VocabularyDeckProps> = ({ masteredIds, onToggleMastered }) => {
  const allVocab = useMemo(() => generateExpandedVocabulary(VOCABULARY_LIST, 10000), []);
  const [selectedCategory, setSelectedCategory] = useState<string>('全部');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [showMeaning, setShowMeaning] = useState<boolean>(false);

  const filteredList: VocabItem[] = useMemo(() => {
    const byCat =
      selectedCategory === '全部'
        ? allVocab
        : allVocab.filter((item) => item.category === selectedCategory);
    const q = searchQuery.trim().toLowerCase();
    if (!q) return byCat;
    return byCat.filter(
      (item) =>
        item.korean.toLowerCase().includes(q) ||
        item.chinese.toLowerCase().includes(q) ||
        item.roman.toLowerCase().includes(q)
    );
  }, [allVocab, selectedCategory, searchQuery]);

  const currentCard = filteredList[currentIndex] || filteredList[0] || allVocab[0];
  const isMastered = !!masteredIds[currentCard.id];

  const handleCategoryChange = (cat: string) => {
    setSelectedCategory(cat);
    setCurrentIndex(0);
    setShowMeaning(false);
  };

  const handlePrev = () => {
    setShowMeaning(false);
    setCurrentIndex((prev) => (prev === 0 ? filteredList.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setShowMeaning(false);
    setCurrentIndex((prev) => (prev === filteredList.length - 1 ? 0 : prev + 1));
  };

  return (
    <div className="flex flex-col gap-3 h-full">
      {/* Search Box & Category Navigation */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 space-y-2.5 shrink-0">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentIndex(0);
              setShowMeaning(false);
            }}
            placeholder={`搜索 ${allVocab.length} 个韩语词汇、罗马音或中文...`}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-sky-600"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => handleCategoryChange(cat)}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Single-Screen Word Card (No 3D Flip, Show/Hide Meaning Toggle) */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex-1 flex flex-col justify-between min-h-0">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span>
            {currentCard.category} · {currentCard.pos}
          </span>
          <span className="font-mono-code">
            {filteredList.length > 0 ? `${currentIndex + 1} / ${filteredList.length}` : '0 / 0'}
          </span>
        </div>

        {/* Center Word & Meaning Area */}
        <div className="my-auto py-3 text-center space-y-3">
          <div className="flex items-center justify-center gap-2.5">
            <span className="font-kr text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
              {currentCard.korean}
            </span>
            <button
              type="button"
              onClick={() => speakKorean(currentCard.korean)}
              className="p-2 rounded-lg bg-sky-50 text-sky-600 hover:bg-sky-100 transition-colors shrink-0"
              aria-label="朗读单词"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>

          {showMeaning ? (
            <div className="pt-3 border-t border-slate-100 space-y-2 text-left bg-slate-50/80 rounded-lg p-3">
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-lg font-bold text-sky-700">{currentCard.chinese}</span>
                <span className="font-mono-code text-xs text-slate-500">[{currentCard.roman}]</span>
              </div>
              <div className="pt-1.5 border-t border-slate-200/70">
                <div className="flex items-center justify-between gap-2">
                  <InteractiveSentence sentence={currentCard.exampleKr} className="text-sm font-medium" />
                  <button
                    type="button"
                    onClick={() => speakKorean(currentCard.exampleKr)}
                    className="p-1.5 rounded bg-white border border-slate-200 text-sky-600 hover:bg-sky-50 shrink-0"
                    title="朗读例句"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-xs text-slate-500 mt-1">{currentCard.exampleCn}</p>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400">点击下方「显示释义」查看中文翻译与例句</p>
          )}
        </div>

        {/* Bottom Card Controls */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={handlePrev}
            className="p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors"
            aria-label="上一个"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => setShowMeaning((v) => !v)}
            className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition-colors"
          >
            {showMeaning ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            <span>{showMeaning ? '隐藏释义' : '显示释义'}</span>
          </button>

          <button
            type="button"
            onClick={() => onToggleMastered(currentCard.id)}
            className={`inline-flex items-center gap-1 px-3 py-2 text-xs font-medium rounded-lg border transition-colors ${
              isMastered
                ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Check className="w-3.5 h-3.5" />
            <span>{isMastered ? '已掌握' : '掌握'}</span>
          </button>

          <button
            type="button"
            onClick={handleNext}
            className="p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors"
            aria-label="下一个"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

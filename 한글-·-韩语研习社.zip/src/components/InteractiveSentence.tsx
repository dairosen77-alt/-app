import React, { useState, useRef, useEffect } from 'react';
import { speakKorean, subscribeWordProgress } from '../utils/speech';
import { KOREAN_WORD_GLOSSARY, VOCABULARY_LIST } from '../data/koreanData';
import { generateExpandedVocabulary, buildFullWordGlossary } from '../data/expandedCorpus';

const COMBINED_GLOSSARY: Record<string, string> = {
  ...buildFullWordGlossary(generateExpandedVocabulary(VOCABULARY_LIST, 10000)),
  ...KOREAN_WORD_GLOSSARY,
};

interface InteractiveSentenceProps {
  sentence: string;
  className?: string;
  dark?: boolean;
}

export const InteractiveSentence: React.FC<InteractiveSentenceProps> = ({
  sentence,
  className = '',
  dark = false,
}) => {
  const [activeGloss, setActiveGloss] = useState<{ index: number; word: string; meaning: string } | null>(null);
  const [readingWordIdx, setReadingWordIdx] = useState<number | null>(null);
  const pressTimerRef = useRef<number | null>(null);
  const isLongPressRef = useRef<boolean>(false);

  useEffect(() => {
    return subscribeWordProgress(sentence, (idx) => {
      setReadingWordIdx(idx);
    });
  }, [sentence]);

  const tokens = sentence.trim().split(/\s+/);

  const cleanToken = (token: string) => token.replace(/[.,!?~"'()]/g, '');

  const lookupMeaning = (rawToken: string): string => {
    const cleaned = cleanToken(rawToken);
    if (COMBINED_GLOSSARY[cleaned]) {
      return COMBINED_GLOSSARY[cleaned];
    }
    const stripped = cleaned.replace(
      /(에서는|에서|으로|부터|까지|처럼|한테|에게|은|는|이|가|을|를|에|로|와|과|도|만)$/,
      ''
    );
    if (stripped && COMBINED_GLOSSARY[stripped]) {
      return COMBINED_GLOSSARY[stripped];
    }
    const keys = Object.keys(COMBINED_GLOSSARY).sort((a, b) => b.length - a.length);
    for (const key of keys) {
      if (cleaned.startsWith(key) && key.length >= 2) {
        return COMBINED_GLOSSARY[key];
      }
    }
    return '韩语词汇（点击可听发音）';
  };

  const handlePointerDown = (idx: number, token: string) => {
    isLongPressRef.current = false;
    if (pressTimerRef.current) {
      window.clearTimeout(pressTimerRef.current);
    }
    pressTimerRef.current = window.setTimeout(() => {
      isLongPressRef.current = true;
      const meaning = lookupMeaning(token);
      setActiveGloss({ index: idx, word: cleanToken(token), meaning });
    }, 380);
  };

  const handlePointerUp = (token: string) => {
    if (pressTimerRef.current) {
      window.clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
    if (!isLongPressRef.current) {
      setActiveGloss(null);
      const cleaned = cleanToken(token);
      if (cleaned) {
        speakKorean(cleaned);
      }
    }
  };

  const handlePointerLeave = () => {
    if (pressTimerRef.current) {
      window.clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
  };

  return (
    <div className={`relative inline-flex flex-wrap items-center gap-x-1.5 gap-y-1 select-none ${className}`}>
      {tokens.map((token, idx) => {
        const isGlossed = activeGloss?.index === idx;
        const isReading = readingWordIdx === idx;
        return (
          <span key={`${token}-${idx}`} className="relative inline-block">
            <button
              type="button"
              onPointerDown={() => handlePointerDown(idx, token)}
              onPointerUp={() => handlePointerUp(token)}
              onPointerLeave={handlePointerLeave}
              onContextMenu={(e) => {
                e.preventDefault();
                setActiveGloss({ index: idx, word: cleanToken(token), meaning: lookupMeaning(token) });
              }}
              title="点击发音 · 长按查看中文释义"
              className={`font-kr px-1.5 py-0.5 rounded-md transition-all duration-150 cursor-pointer ${
                dark
                  ? 'hover:bg-slate-800 active:bg-sky-900/60 text-slate-100'
                  : 'hover:bg-sky-100/80 active:bg-sky-200/80 text-slate-900'
              } ${
                isReading
                  ? dark
                    ? 'ring-2 ring-sky-400 bg-sky-900/90 text-white scale-[1.03]'
                    : 'ring-2 ring-sky-500 bg-sky-100 text-sky-950 scale-[1.03]'
                  : isGlossed
                  ? dark
                    ? 'bg-sky-900/80 text-sky-200'
                    : 'bg-sky-100 text-sky-900'
                  : ''
              }`}
            >
              {token}
            </button>

            {isGlossed && activeGloss && (
              <span
                role="tooltip"
                className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 z-20 px-2.5 py-1 rounded-md bg-slate-900 text-white text-xs font-normal whitespace-nowrap shadow-md pointer-events-none"
              >
                {activeGloss.meaning}
              </span>
            )}
          </span>
        );
      })}
    </div>
  );
};

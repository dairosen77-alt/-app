import React, { useState } from 'react';
import { ArrowLeftRight, Volume2, Copy, Check, Loader2, Languages } from 'lucide-react';
import { speakKorean } from '../utils/speech';

interface TranslationResult {
  translatedText: string;
  romanization: string;
  notes: string;
}

const SAMPLE_PHRASES = {
  'ko-to-zh': [
    '오늘 날씨가 정말 좋아서 한강에 산책하러 가고 싶어요.',
    '이 근처에 맛있는 김치찌개 식당이 어디에 있어요?',
    '한국어를 배운 지 석 달 되었는데 아직 많이 부족해요.',
  ],
  'zh-to-ko': [
    '请问附近有地铁站吗？我想去明洞。',
    '这件衣服可以试穿一下吗？有没有大一点的尺码？',
    '今天能见到你真的很开心，下次一起喝咖啡吧！',
  ],
};

export const TranslatorStudio: React.FC = () => {
  const [direction, setDirection] = useState<'ko-to-zh' | 'zh-to-ko'>('ko-to-zh');
  const [inputText, setInputText] = useState<string>('');
  const [result, setResult] = useState<TranslationResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const isKoToZh = direction === 'ko-to-zh';

  const handleSwapDirection = () => {
    const nextDir = isKoToZh ? 'zh-to-ko' : 'ko-to-zh';
    setDirection(nextDir);
    if (result?.translatedText) {
      setInputText(result.translatedText);
      setResult(null);
    }
    setError(null);
  };

  const handleTranslate = async (textToTranslate?: string) => {
    const query = (textToTranslate ?? inputText).trim();
    if (!query) {
      setError('请输入需要翻译的句子');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: query, direction }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || '翻译失败，请稍后重试');
      }

      setResult(data as TranslationResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : '网络请求失败');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Ignore clipboard errors
    }
  };

  const koreanTextForAudio = isKoToZh ? inputText : result?.translatedText || '';

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
      {/* Header & Direction Switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">韩汉双向智能翻译</h2>
          <p className="text-sm text-slate-500 mt-0.5">支持韩语与中文互译，自动附带罗马音标注与核心语法解析</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => {
                setDirection('ko-to-zh');
                setResult(null);
                setError(null);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                isKoToZh ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              韩语 → 中文
            </button>
            <button
              type="button"
              onClick={() => {
                setDirection('zh-to-ko');
                setResult(null);
                setError(null);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                !isKoToZh ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              中文 → 韩语
            </button>
          </div>

          <button
            type="button"
            onClick={handleSwapDirection}
            className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors"
            title="切换翻译方向"
            aria-label="切换翻译方向"
          >
            <ArrowLeftRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Two-Column Input & Output Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left: Input Box */}
        <div className="lg:col-span-6 flex flex-col justify-between bg-slate-50 border border-slate-200 rounded-xl p-5">
          <div>
            <div className="flex items-center justify-between text-xs font-medium text-slate-600 mb-2">
              <span>{isKoToZh ? '输入韩语句子 (한국어)' : '输入中文句子 (中文)'}</span>
              {inputText && (
                <button
                  type="button"
                  onClick={() => {
                    setInputText('');
                    setResult(null);
                    setError(null);
                  }}
                  className="text-slate-400 hover:text-slate-700"
                >
                  清空
                </button>
              )}
            </div>

            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              rows={5}
              placeholder={
                isKoToZh
                  ? '例如：안녕하세요, 오늘 날씨가 정말 좋네요!'
                  : '例如：你好，请问去首尔塔怎么走？'
              }
              className={`w-full bg-white border border-slate-200 rounded-lg p-3.5 text-base text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-sky-600 resize-none ${
                isKoToZh ? 'font-kr' : ''
              }`}
            />
          </div>

          <div className="mt-4 flex items-center justify-between gap-3">
            {isKoToZh && inputText.trim() ? (
              <button
                type="button"
                onClick={() => speakKorean(inputText)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <Volume2 className="w-4 h-4" />
                <span>朗读原文</span>
              </button>
            ) : (
              <div />
            )}

            <button
              type="button"
              disabled={isLoading}
              onClick={() => handleTranslate()}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-medium text-white bg-sky-600 hover:bg-sky-700 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Languages className="w-4 h-4" />}
              <span>{isLoading ? '正在翻译...' : '立即翻译'}</span>
            </button>
          </div>
        </div>

        {/* Right: Output Box */}
        <div className="lg:col-span-6 flex flex-col justify-between bg-white border border-slate-200 rounded-xl p-5">
          {error ? (
            <div className="my-auto text-center py-8">
              <p className="text-sm font-medium text-rose-600">{error}</p>
            </div>
          ) : result ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs font-medium text-slate-500">
                <span>{isKoToZh ? '中文译文' : '韩语译文 (敬语体)'}</span>
                <div className="flex items-center gap-2">
                  {koreanTextForAudio && (
                    <button
                      type="button"
                      onClick={() => speakKorean(koreanTextForAudio)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-md transition-colors"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>朗读韩语</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => handleCopy(result.translatedText)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? '已复制' : '复制'}</span>
                  </button>
                </div>
              </div>

              <div className={`text-xl font-semibold text-slate-900 leading-relaxed ${!isKoToZh ? 'font-kr text-2xl' : ''}`}>
                {result.translatedText}
              </div>

              {result.romanization && (
                <div className="font-mono-code text-xs text-sky-700 bg-sky-50/70 border border-sky-100 rounded-lg px-3 py-2">
                  [{result.romanization}]
                </div>
              )}

              {result.notes && (
                <div className="pt-3 border-t border-slate-100">
                  <div className="text-xs font-medium text-slate-500 mb-1">词汇与语法解析</div>
                  <p className="text-sm text-slate-600 leading-relaxed">{result.notes}</p>
                </div>
              )}
            </div>
          ) : (
            <div className="my-auto text-center py-10 text-slate-400">
              <p className="text-sm">翻译结果、罗马音标注及语法解析将显示在这里</p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Sample Phrases */}
      <div className="pt-4 border-t border-slate-100">
        <div className="text-xs font-medium text-slate-500 mb-2.5">点击下方例句快速体验：</div>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_PHRASES[direction].map((sample) => (
            <button
              key={sample}
              type="button"
              onClick={() => {
                setInputText(sample);
                handleTranslate(sample);
              }}
              className={`px-3 py-1.5 text-xs text-slate-700 bg-slate-50 hover:bg-sky-50 hover:text-sky-900 border border-slate-200 hover:border-sky-200 rounded-lg transition-colors text-left ${
                isKoToZh ? 'font-kr' : ''
              }`}
            >
              {sample}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

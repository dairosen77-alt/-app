import React, { useState } from 'react';
import { Volume2, RotateCcw, CheckCircle2, HelpCircle } from 'lucide-react';
import {
  BASIC_CONSONANTS,
  TENSE_CONSONANTS,
  BASIC_VOWELS,
  COMPOUND_VOWELS,
  INITIAL_JAMO,
  MEDIAL_JAMO,
  FINAL_JAMO,
  composeHangul,
  JamoItem,
} from '../data/koreanData';
import { speakKorean } from '../utils/speech';

type JamoTab = 'basic_consonant' | 'tense_consonant' | 'basic_vowel' | 'compound_vowel';

const QUIZ_POOL = [
  { char: '가', roman: 'ga' },
  { char: '나', roman: 'na' },
  { char: '다', roman: 'da' },
  { char: '라', roman: 'ra' },
  { char: '마', roman: 'ma' },
  { char: '바', roman: 'ba' },
  { char: '사', roman: 'sa' },
  { char: '아', roman: 'a' },
  { char: '자', roman: 'ja' },
  { char: '카', roman: 'ka' },
  { char: '타', roman: 'ta' },
  { char: '파', roman: 'pa' },
  { char: '하', roman: 'ha' },
  { char: '고', roman: 'go' },
  { char: '노', roman: 'no' },
  { char: '두', roman: 'du' },
  { char: '무', roman: 'mu' },
  { char: '서', roman: 'seo' },
  { char: '여', roman: 'yeo' },
  { char: '우', roman: 'u' },
];

export const HangulLab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<JamoTab>('basic_consonant');
  const [selectedJamo, setSelectedJamo] = useState<JamoItem>(BASIC_CONSONANTS[0]);
  const [speechRate, setSpeechRate] = useState<number>(0.95);

  // Syllable Composer state
  const [initialIdx, setInitialIdx] = useState<number>(0); // ㄱ
  const [medialIdx, setMedialIdx] = useState<number>(0); // ㅏ
  const [finalIdx, setFinalIdx] = useState<number>(0); // none
  const composed = composeHangul(initialIdx, medialIdx, finalIdx);

  // Listening Quiz state
  const [quizTarget, setQuizTarget] = useState(() => QUIZ_POOL[0]);
  const [quizOptions, setQuizOptions] = useState(() => QUIZ_POOL.slice(0, 4));
  const [quizFeedback, setQuizFeedback] = useState<'idle' | 'correct' | 'wrong'>('idle');
  const [quizStreak, setQuizStreak] = useState<number>(0);

  const currentList =
    activeTab === 'basic_consonant'
      ? BASIC_CONSONANTS
      : activeTab === 'tense_consonant'
      ? TENSE_CONSONANTS
      : activeTab === 'basic_vowel'
      ? BASIC_VOWELS
      : COMPOUND_VOWELS;

  const handleSelectJamo = (item: JamoItem) => {
    setSelectedJamo(item);
    speakKorean(item.char, speechRate);
  };

  const generateNewQuiz = () => {
    const shuffled = [...QUIZ_POOL].sort(() => Math.random() - 0.5);
    const options = shuffled.slice(0, 4);
    const target = options[Math.floor(Math.random() * options.length)];
    setQuizOptions(options);
    setQuizTarget(target);
    setQuizFeedback('idle');
    speakKorean(target.char, speechRate);
  };

  const handleQuizAnswer = (char: string) => {
    if (char === quizTarget.char) {
      setQuizFeedback('correct');
      setQuizStreak((s) => s + 1);
      setTimeout(() => {
        generateNewQuiz();
      }, 900);
    } else {
      setQuizFeedback('wrong');
      setQuizStreak(0);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Two-Zone Interactive Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Zone (7 cols): 40-Jamo Matrix */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-100">
              <div>
                <h2 className="text-xl font-semibold text-slate-900">韩文字母发音矩阵</h2>
                <p className="text-sm text-slate-500 mt-0.5">点击任意字母聆听标准首尔发音并查看舌位图解</p>
              </div>
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setSpeechRate(0.7)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    speechRate === 0.7 ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  慢速 0.7x
                </button>
                <button
                  type="button"
                  onClick={() => setSpeechRate(0.95)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    speechRate === 0.95 ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  常速 1.0x
                </button>
              </div>
            </div>

            {/* Category Segmented Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-lg my-5">
              {(
                [
                  { id: 'basic_consonant', label: '基本辅音 (14)' },
                  { id: 'tense_consonant', label: '紧音 (5)' },
                  { id: 'basic_vowel', label: '基本元音 (10)' },
                  { id: 'compound_vowel', label: '复合元音 (11)' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab.id);
                    const first =
                      tab.id === 'basic_consonant'
                        ? BASIC_CONSONANTS[0]
                        : tab.id === 'tense_consonant'
                        ? TENSE_CONSONANTS[0]
                        : tab.id === 'basic_vowel'
                        ? BASIC_VOWELS[0]
                        : COMPOUND_VOWELS[0];
                    setSelectedJamo(first);
                  }}
                  className={`flex-1 px-3 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === tab.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Jamo Grid */}
            <div className="grid grid-cols-5 sm:grid-cols-7 gap-2.5">
              {currentList.map((item) => {
                const isSelected = selectedJamo.char === item.char;
                return (
                  <button
                    key={item.char}
                    type="button"
                    onClick={() => handleSelectJamo(item)}
                    className={`group flex flex-col items-center justify-center py-3.5 px-2 rounded-lg border transition-all ${
                      isSelected
                        ? 'bg-sky-50 border-sky-600 text-sky-900'
                        : 'bg-slate-50/60 border-slate-200 text-slate-800 hover:bg-white hover:border-slate-300'
                    }`}
                  >
                    <span className="font-kr text-2xl font-bold leading-none">{item.char}</span>
                    <span className="font-mono-code text-xs text-slate-500 mt-1.5">{item.roman}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Jamo Articulation Inspector */}
          <div className="mt-6 pt-5 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-xl bg-slate-900 text-white flex items-center justify-center font-kr text-3xl font-bold shrink-0">
                {selectedJamo.char}
              </div>
              <div>
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <span className="font-semibold text-slate-900">名称：{selectedJamo.name}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-code text-sky-700 font-medium">[{selectedJamo.roman}]</span>
                </div>
                <p className="text-sm text-slate-600 mt-1">{selectedJamo.articulation}</p>
                <p className="text-xs text-slate-500 mt-1">
                  例词：<span className="font-kr font-semibold text-slate-800">{selectedJamo.exampleWord}</span>（{selectedJamo.exampleMeaning}）
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => speakKorean(`${selectedJamo.char}, ${selectedJamo.exampleWord}`, speechRate)}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <Volume2 className="w-4 h-4" />
              <span>跟读发音</span>
            </button>
          </div>
        </div>

        {/* Right Zone (5 cols): Interactive Syllable Composer */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <div className="pb-5 border-b border-slate-100">
              <h2 className="text-xl font-semibold text-slate-900">音节拼读实验室</h2>
              <p className="text-sm text-slate-500 mt-0.5">自由组合初声（辅音）+ 中声（元音）+ 终声（收音）</p>
            </div>

            {/* Live Composed Syllable Stage */}
            <div className="my-6 p-6 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-500">合成韩语音节</div>
                <div className="flex items-baseline gap-3 mt-1">
                  <span className="font-kr text-6xl font-bold text-slate-900">{composed.char}</span>
                  <span className="font-mono-code text-lg font-medium text-sky-700">[{composed.roman}]</span>
                </div>
                <div className="text-xs text-slate-500 mt-2 font-mono-code">
                  {INITIAL_JAMO[initialIdx]} + {MEDIAL_JAMO[medialIdx]}
                  {finalIdx > 0 ? ` + ${FINAL_JAMO[finalIdx]} (收音)` : ' (无收音)'}
                </div>
              </div>
              <button
                type="button"
                onClick={() => speakKorean(composed.char, speechRate)}
                className="w-12 h-12 rounded-xl bg-sky-600 hover:bg-sky-700 text-white flex items-center justify-center transition-colors shrink-0"
                aria-label="播放合成音节"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>

            {/* 3-Step Selector */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">1. 选择初声（辅音）</label>
                <div className="flex flex-wrap gap-1.5">
                  {INITIAL_JAMO.slice(0, 14).map((jamo, idx) => (
                    <button
                      key={jamo}
                      type="button"
                      onClick={() => {
                        setInitialIdx(idx);
                        speakKorean(composeHangul(idx, medialIdx, finalIdx).char, speechRate);
                      }}
                      className={`w-8 h-8 rounded-md font-kr text-sm font-semibold border transition-colors ${
                        initialIdx === idx
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {jamo}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">2. 选择中声（元音）</label>
                <div className="flex flex-wrap gap-1.5">
                  {MEDIAL_JAMO.slice(0, 10).map((jamo, idx) => {
                    const actualIdx = MEDIAL_JAMO.indexOf(jamo);
                    return (
                      <button
                        key={jamo}
                        type="button"
                        onClick={() => {
                          setMedialIdx(actualIdx);
                          speakKorean(composeHangul(initialIdx, actualIdx, finalIdx).char, speechRate);
                        }}
                        className={`w-8 h-8 rounded-md font-kr text-sm font-semibold border transition-colors ${
                          medialIdx === actualIdx
                            ? 'bg-sky-600 text-white border-sky-600'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {jamo}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">3. 选择终声（常用收音 받침）</label>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { label: '无', idx: 0 },
                    { label: 'ㄱ', idx: 1 },
                    { label: 'ㄴ', idx: 4 },
                    { label: 'ㄷ', idx: 7 },
                    { label: 'ㄹ', idx: 8 },
                    { label: 'ㅁ', idx: 16 },
                    { label: 'ㅂ', idx: 17 },
                    { label: 'ㅇ', idx: 21 },
                  ].map((item) => (
                    <button
                      key={item.label}
                      type="button"
                      onClick={() => {
                        setFinalIdx(item.idx);
                        speakKorean(composeHangul(initialIdx, medialIdx, item.idx).char, speechRate);
                      }}
                      className={`px-2.5 h-8 rounded-md font-kr text-xs font-semibold border transition-colors ${
                        finalIdx === item.idx
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Listening Quiz Strip */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => speakKorean(quizTarget.char, speechRate)}
            className="w-12 h-12 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 hover:bg-sky-100 flex items-center justify-center transition-colors shrink-0"
            aria-label="播放测验发音"
          >
            <Volume2 className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span>听音辨字小测验</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-code text-slate-700">连对 {quizStreak} 题</span>
            </div>
            <h3 className="text-base font-semibold text-slate-900 mt-0.5">点击左侧喇叭听发音，选出对应的韩文字母</h3>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {quizOptions.map((opt) => (
            <button
              key={opt.char}
              type="button"
              onClick={() => handleQuizAnswer(opt.char)}
              className="w-14 h-14 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white hover:border-sky-500 font-kr text-2xl font-bold text-slate-900 transition-all"
            >
              {opt.char}
            </button>
          ))}
          <button
            type="button"
            onClick={generateNewQuiz}
            className="p-3 rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors"
            title="换一题"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        <div className="min-w-[120px] flex items-center justify-end">
          {quizFeedback === 'correct' && (
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700">
              <CheckCircle2 className="w-4 h-4" />
              <span>回答正确！</span>
            </span>
          )}
          {quizFeedback === 'wrong' && (
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-600">
              <HelpCircle className="w-4 h-4" />
              <span>再听一次试试</span>
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

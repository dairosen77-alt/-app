import React, { useState, useMemo } from 'react';
import { Volume2, Eye, EyeOff, Mic, MicOff } from 'lucide-react';
import { generateDialogueScenarios } from '../data/expandedCorpus';
import { speakKorean } from '../utils/speech';
import { InteractiveSentence } from './InteractiveSentence';

interface SpeechRecognitionEventLike {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
    };
  };
}

interface SpeechRecognitionLike {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
}

function calculateSimilarity(target: string, spoken: string): number {
  const clean = (s: string) => s.replace(/[\s.,!?~"'()]/g, '');
  const a = clean(target);
  const b = clean(spoken);
  if (!a || !b) return 0;
  if (a === b) return 100;

  const dp: number[][] = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;

  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }

  const distance = dp[a.length][b.length];
  const maxLen = Math.max(a.length, b.length);
  return Math.max(0, Math.round(((maxLen - distance) / maxLen) * 100));
}

const DIALOGUE_CATS = ['全部', '餐饮购物', '交通出行', '职场校园', '医疗银行', '休闲旅游'] as const;

export const DialoguePractice: React.FC = () => {
  const scenarios = useMemo(() => generateDialogueScenarios(100, 8), []);
  const [selectedCat, setSelectedCat] = useState<string>('全部');
  const [selectedId, setSelectedId] = useState<string>(scenarios[0].id);
  const [showRoman, setShowRoman] = useState<boolean>(true);
  const [showChinese, setShowChinese] = useState<boolean>(true);

  const [recordingIdx, setRecordingIdx] = useState<number | null>(null);
  const [scores, setScores] = useState<Record<string, { score: number; transcript: string }>>({});
  const [speechError, setSpeechError] = useState<string | null>(null);

  const filteredScenarios = useMemo(() => {
    if (selectedCat === '全部') return scenarios;
    return scenarios.filter((sc) => {
      if (selectedCat === '餐饮购物') return /咖啡|烤肉|便利店|服装|超市|市场/.test(sc.title);
      if (selectedCat === '交通出行') return /地铁|机场|出租车|租车/.test(sc.title);
      if (selectedCat === '职场校园') return /公司|大学|书店|邮局/.test(sc.title);
      if (selectedCat === '医疗银行') return /医院|药店|银行|酒店/.test(sc.title);
      return /美容|汉江|电影|健身|海云台|博物馆|演唱会/.test(sc.title);
    });
  }, [scenarios, selectedCat]);

  const currentScenario =
    filteredScenarios.find((d) => d.id === selectedId) || filteredScenarios[0] || scenarios[0];

  const handleStartPractice = (turnIdx: number, targetKorean: string) => {
    setSpeechError(null);
    const SpeechRec =
      (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionLike }).webkitSpeechRecognition;

    if (!SpeechRec) {
      setSpeechError('当前浏览器不支持 Web Speech 语音识别，建议使用 Chrome 或 Edge 浏览器。');
      return;
    }

    try {
      const recognition = new SpeechRec();
      recognition.lang = 'ko-KR';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      setRecordingIdx(turnIdx);

      recognition.onresult = (event: SpeechRecognitionEventLike) => {
        const transcript = event.results[0]?.[0]?.transcript || '';
        const score = calculateSimilarity(targetKorean, transcript);
        const key = `${currentScenario.id}-${turnIdx}`;
        setScores((prev) => ({ ...prev, [key]: { score, transcript } }));
        setRecordingIdx(null);
      };

      recognition.onerror = () => {
        setRecordingIdx(null);
        setSpeechError('未检测到清晰语音，请靠近麦克风重试。');
      };

      recognition.onend = () => {
        setRecordingIdx(null);
      };

      recognition.start();
    } catch {
      setRecordingIdx(null);
      setSpeechError('无法启动麦克风，请检查浏览器权限。');
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-3.5 flex flex-col gap-3 h-full overflow-hidden">
      <div className="flex flex-col gap-2 pb-2.5 border-b border-slate-100 shrink-0">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-base font-semibold text-slate-900">首尔情景对话</h2>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setShowRoman((v) => !v)}
              className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-md"
            >
              {showRoman ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
              <span>罗马音</span>
            </button>
            <button
              type="button"
              onClick={() => setShowChinese((v) => !v)}
              className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-md"
            >
              {showChinese ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
              <span>中文</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
          {DIALOGUE_CATS.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => {
                setSelectedCat(cat);
                setSpeechError(null);
              }}
              className={`px-2 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedCat === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <select
            value={currentScenario.id}
            onChange={(e) => {
              setSelectedId(e.target.value);
              setSpeechError(null);
            }}
            aria-label="选择情景对话场景"
            className="w-full px-2.5 py-1.5 text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:border-sky-600"
          >
            {filteredScenarios.map((sc, idx) => (
              <option key={sc.id} value={sc.id}>
                {idx + 1}. {sc.title} ({sc.turns.length}句)
              </option>
            ))}
          </select>
        </div>
      </div>

      {speechError && (
        <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
          {speechError}
        </div>
      )}

      {/* Scenario Header */}
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>
          场景：{currentScenario.location} · {currentScenario.level}
        </span>
        <span>共 {currentScenario.turns.length} 句对话</span>
      </div>

      {/* Dialogue Turns */}
      <div className="space-y-2.5 overflow-y-auto flex-1 pr-0.5">
        {currentScenario.turns.map((turn, idx) => {
          const isLearner = turn.role === 'learner';
          const scoreKey = `${currentScenario.id}-${idx}`;
          const result = scores[scoreKey];
          const isRecording = recordingIdx === idx;
          const voiceGender = isLearner ? 'male' : 'female';

          return (
            <div
              key={idx}
              className={`flex flex-col ${isLearner ? 'items-end' : 'items-start'}`}
            >
              <div className="text-[11px] text-slate-500 mb-0.5 px-1">
                {turn.speaker} ({voiceGender === 'male' ? '男声' : '女声'})
              </div>
              <div
                className={`w-full text-left p-3 rounded-xl border transition-all ${
                  isLearner
                    ? 'bg-sky-50/70 border-sky-200 text-slate-900'
                    : 'bg-slate-50 border-slate-200 text-slate-900'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <InteractiveSentence sentence={turn.korean} className="text-sm font-semibold leading-snug" />
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => speakKorean(turn.korean, 0.95, voiceGender)}
                      title="整句朗读"
                      className="p-1.5 rounded-lg bg-white border border-slate-200 text-sky-600 hover:bg-sky-50 transition-colors"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleStartPractice(idx, turn.korean)}
                      title="跟读发音评分"
                      className={`inline-flex items-center gap-1 px-2 py-1.5 rounded-lg text-[11px] font-medium border transition-colors ${
                        isRecording
                          ? 'bg-rose-600 text-white border-rose-600'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-sky-400 hover:text-sky-700'
                      }`}
                    >
                      {isRecording ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
                      <span>{isRecording ? '聆听中' : '评分'}</span>
                    </button>
                  </div>
                </div>

                {showRoman && (
                  <div className="font-mono-code text-xs text-sky-700 mt-1.5">{turn.roman}</div>
                )}
                {showChinese && (
                  <div className="text-sm text-slate-600 mt-1">{turn.chinese}</div>
                )}

                {result && (
                  <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="text-slate-500">
                      识别结果：<span className="font-kr text-slate-800">{result.transcript}</span>
                    </span>
                    <span
                      className={`font-mono-code font-semibold ${
                        result.score >= 80
                          ? 'text-emerald-700'
                          : result.score >= 55
                          ? 'text-amber-700'
                          : 'text-rose-600'
                      }`}
                    >
                      准确度 {result.score}% ·{' '}
                      {result.score >= 80 ? '发音很标准' : result.score >= 55 ? '较准确，继续加油' : '建议再听一次跟读'}
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

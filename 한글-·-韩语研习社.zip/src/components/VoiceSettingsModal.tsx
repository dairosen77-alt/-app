import React, { useState, useEffect } from 'react';
import { X, Volume2, Download, CheckCircle2, Loader2 } from 'lucide-react';
import {
  VoiceSettings,
  VOICE_ROLE_OPTIONS,
  getVoiceSettings,
  updateVoiceSettings,
  speakKorean,
} from '../utils/speech';

interface VoiceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TTSStats {
  totalRequests: number;
  cacheHits: number;
  hitRate: number;
  cacheSize: number;
  lastProvider: string;
}

const SPEED_OPTIONS = [0.5, 0.75, 0.85, 1.0, 1.1, 1.2];

const CORE_PREFETCH_TEXTS = [
  '안녕하세요',
  '감사합니다',
  '죄송합니다',
  '괜찮아요',
  '아이스 아메리카노 한 잔 주세요.',
  '이거 얼마예요?',
  '지하철역이 어디예요?',
  '오늘 날씨가 정말 좋네요!',
  '보고 싶어요.',
  '사랑해요.',
];

export const VoiceSettingsModal: React.FC<VoiceSettingsModalProps> = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState<VoiceSettings>(() => getVoiceSettings());
  const [stats, setStats] = useState<TTSStats | null>(null);
  const [isPrefetching, setIsPrefetching] = useState(false);
  const [prefetchDone, setPrefetchDone] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setSettings(getVoiceSettings());
    fetch('/api/tts/stats')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data) setStats(data);
      })
      .catch(() => {});
  }, [isOpen]);

  if (!isOpen) return null;

  const handleUpdate = (patch: Partial<VoiceSettings>) => {
    const next = updateVoiceSettings(patch);
    setSettings(next);
  };

  const handleModeChange = (mode: 'standard' | 'drama') => {
    const defaultRate = mode === 'drama' ? 1.0 : 0.85;
    handleUpdate({ mode, rate: defaultRate });
  };

  const handlePrefetch = async () => {
    setIsPrefetching(true);
    setPrefetchDone(false);
    try {
      for (const text of CORE_PREFETCH_TEXTS) {
        await speakKorean(text, settings.rate, settings.roleId);
      }
      setPrefetchDone(true);
      const res = await fetch('/api/tts/stats');
      if (res.ok) setStats(await res.json());
    } finally {
      setIsPrefetching(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md max-h-[90dvh] flex flex-col overflow-hidden shadow-xl">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between shrink-0">
          <h2 className="text-base font-bold text-slate-900">韩语 AI 语音设置</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            aria-label="关闭设置"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 space-y-4 overflow-y-auto text-xs">
          {/* 1. 发音模式 */}
          <div>
            <label className="block font-semibold text-slate-800 mb-1.5">1. 发音模式</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleModeChange('standard')}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  settings.mode === 'standard'
                    ? 'bg-sky-50 border-sky-600 text-sky-950'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="font-semibold">标准学习模式</div>
                <div className="text-[11px] text-slate-500 mt-0.5">清晰准确 · 默认 0.85x</div>
              </button>

              <button
                type="button"
                onClick={() => handleModeChange('drama')}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  settings.mode === 'drama'
                    ? 'bg-sky-50 border-sky-600 text-sky-950'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="font-semibold">韩剧自然对话模式</div>
                <div className="text-[11px] text-slate-500 mt-0.5">情感语气 · 默认 1.0x</div>
              </button>
            </div>
          </div>

          {/* 2. 声音角色 */}
          <div>
            <label className="block font-semibold text-slate-800 mb-1.5">2. 声音角色（点击试听）</label>
            <div className="space-y-1.5">
              {VOICE_ROLE_OPTIONS.map((role) => {
                const isSelected = settings.roleId === role.id;
                return (
                  <div
                    key={role.id}
                    onClick={() => handleUpdate({ roleId: role.id })}
                    className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-sky-50 border-sky-600 text-sky-950'
                        : 'bg-slate-50/70 border-slate-200 text-slate-800 hover:bg-white'
                    }`}
                  >
                    <div>
                      <div className="font-semibold">{role.label}</div>
                      <div className="text-[11px] text-slate-500">{role.desc}</div>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleUpdate({ roleId: role.id });
                        speakKorean('안녕하세요, 오늘 날씨가 정말 좋네요!', settings.rate, role.id);
                      }}
                      className="p-2 rounded-lg bg-white border border-slate-200 text-sky-600 hover:bg-sky-50 shrink-0"
                      title="试听该声音"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 3. 播放速度 */}
          <div>
            <label className="block font-semibold text-slate-800 mb-1.5">3. 播放速度</label>
            <div className="grid grid-cols-6 gap-1.5">
              {SPEED_OPTIONS.map((spd) => (
                <button
                  key={spd}
                  type="button"
                  onClick={() => handleUpdate({ rate: spd })}
                  className={`py-1.5 rounded-lg font-mono-code font-medium border transition-colors ${
                    settings.rate === spd
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-white'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>

          {/* 4. 播放辅助选项 */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-100">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.loopSingle}
                onChange={(e) => handleUpdate({ loopSingle: e.target.checked })}
                className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
              />
              <span className="text-slate-700 font-medium">单句重复播放</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.useSystemFallback}
                onChange={(e) => handleUpdate({ useSystemFallback: e.target.checked })}
                className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
              />
              <span className="text-slate-700 font-medium">离线系统语音备用</span>
            </label>
          </div>

          {/* 5. 离线预生成与用量统计 */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800">离线缓存与用量统计</span>
              {stats && (
                <span className="font-mono-code text-[11px] text-sky-700">
                  命中率 {stats.hitRate}% ({stats.cacheHits}/{stats.totalRequests})
                </span>
              )}
            </div>

            <button
              type="button"
              disabled={isPrefetching}
              onClick={handlePrefetch}
              className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-white border border-slate-200 hover:border-sky-400 text-slate-800 font-medium transition-colors disabled:opacity-50"
            >
              {isPrefetching ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-600" />
              ) : prefetchDone ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <Download className="w-3.5 h-3.5 text-sky-600" />
              )}
              <span>
                {isPrefetching
                  ? '正在预生成常用教材音频...'
                  : prefetchDone
                  ? '常用教材音频已缓存（支持离线播放）'
                  : '一键预生成常用教材音频（离线可用）'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

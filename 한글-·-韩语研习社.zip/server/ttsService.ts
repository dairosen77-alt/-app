import { GoogleGenAI } from '@google/genai';
import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts';

export type VoiceRoleId = 'female_a' | 'female_b' | 'male_a' | 'male_b';
export type SpeechMode = 'standard' | 'drama';

export interface VoiceRoleConfig {
  id: VoiceRoleId;
  label: string;
  gender: 'female' | 'male';
  description: string;
  elevenLabsId: string;
  azureVoice: string;
  googleChirpVoice: string;
  geminiVoice: string;
}

export const VOICE_ROLES: Record<VoiceRoleId, VoiceRoleConfig> = {
  female_a: {
    id: 'female_a',
    label: '女声 A · 温柔治愈型',
    gender: 'female',
    description: '温柔、柔和、自然，适合日常生活及情感对话',
    elevenLabsId: '21m00Tcm4TlvDq8ikWAM',
    azureVoice: 'ko-KR-SunHiNeural',
    googleChirpVoice: 'ko-KR-Chirp3-HD-Aoede',
    geminiVoice: 'Kore',
  },
  female_b: {
    id: 'female_b',
    label: '女声 B · 活泼甜美型',
    gender: 'female',
    description: '清新、明亮、自然，适合年轻人日常交流',
    elevenLabsId: 'EXAVITQu4vr4xnSDxMaL',
    azureVoice: 'ko-KR-JiMinNeural',
    googleChirpVoice: 'ko-KR-Chirp3-HD-Leda',
    geminiVoice: 'Aoede',
  },
  male_a: {
    id: 'male_a',
    label: '男声 A · 低沉磁性型',
    gender: 'male',
    description: '沉稳、温暖、有磁性，适合韩剧男主角日常交流',
    elevenLabsId: 'pNInz6obpgDQGcFmaJgB',
    azureVoice: 'ko-KR-InJoonNeural',
    googleChirpVoice: 'ko-KR-Chirp3-HD-Charon',
    geminiVoice: 'Charon',
  },
  male_b: {
    id: 'male_b',
    label: '男声 B · 阳光温暖型',
    gender: 'male',
    description: '轻松、亲切、自然，适合朋友和生活场景对话',
    elevenLabsId: 'TxGEqnHWrfWFTfGW9XjX',
    azureVoice: 'ko-KR-BongJinNeural',
    googleChirpVoice: 'ko-KR-Chirp3-HD-Puck',
    geminiVoice: 'Puck',
  },
};

interface CachedAudio {
  buffer: Buffer;
  contentType: string;
  provider: string;
}

const audioCache = new Map<string, CachedAudio>();

const stats = {
  totalRequests: 0,
  cacheHits: 0,
  providerCalls: {} as Record<string, number>,
  lastProvider: 'none',
};

function recordProviderCall(provider: string) {
  stats.providerCalls[provider] = (stats.providerCalls[provider] || 0) + 1;
  stats.lastProvider = provider;
}

export function getTTSStats() {
  const hitRate =
    stats.totalRequests > 0 ? Math.round((stats.cacheHits / stats.totalRequests) * 100) : 0;
  return {
    ...stats,
    cacheSize: audioCache.size,
    hitRate,
  };
}

function pcmToWav(pcmBuffer: Buffer, sampleRate = 24000, numChannels = 1, bitsPerSample = 16): Buffer {
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + pcmBuffer.length, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write('data', 36);
  header.writeUInt32LE(pcmBuffer.length, 40);
  return Buffer.concat([header, pcmBuffer]);
}

function detectDramaEmotion(text: string): string {
  if (text.includes('?')) return '好奇、自然的疑问语气';
  if (text.includes('!')) return '开心、惊讶或充满感情的语气';
  if (/미안|죄송|슬프|눈물|이별|후회/.test(text)) return '温柔、略带感伤与关切的语气';
  if (/사랑|행복|좋아|고마워|약속/.test(text)) return '温暖、亲切、充满爱意的语气';
  return '自然、松弛的韩国首尔日常对话语气';
}

async function tryElevenLabs(text: string, role: VoiceRoleConfig, mode: SpeechMode): Promise<CachedAudio | null> {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) return null;

  try {
    const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${role.elevenLabsId}`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        Accept: 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: mode === 'standard' ? 0.75 : 0.45,
          similarity_boost: 0.8,
          style: mode === 'drama' ? 0.45 : 0.1,
        },
      }),
    });

    if (!res.ok) return null;
    const buffer = Buffer.from(await res.arrayBuffer());
    recordProviderCall('ElevenLabs');
    return { buffer, contentType: 'audio/mpeg', provider: 'ElevenLabs' };
  } catch {
    return null;
  }
}

async function tryAzureSpeech(
  text: string,
  role: VoiceRoleConfig,
  mode: SpeechMode,
  rate: number
): Promise<CachedAudio | null> {
  const apiKey = process.env.AZURE_SPEECH_KEY;
  const region = process.env.AZURE_SPEECH_REGION || 'koreacentral';
  if (!apiKey) return null;

  try {
    const ratePct = `${Math.round((rate - 1) * 100)}%`;
    const ssml = `<speak version='1.0' xml:lang='ko-KR'>
      <voice name='${role.azureVoice}'>
        <prosody rate='${ratePct}' pitch='${mode === 'drama' ? '+2%' : '0%'}'>
          ${text.replace(/[<>&'"]/g, '')}
        </prosody>
      </voice>
    </speak>`;

    const res = await fetch(`https://${region}.tts.speech.microsoft.com/cognitiveservices/v1`, {
      method: 'POST',
      headers: {
        'Ocp-Apim-Subscription-Key': apiKey,
        'Content-Type': 'application/ssml+xml',
        'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3',
      },
      body: ssml,
    });

    if (!res.ok) return null;
    const buffer = Buffer.from(await res.arrayBuffer());
    recordProviderCall('Azure Speech');
    return { buffer, contentType: 'audio/mpeg', provider: 'Azure Speech' };
  } catch {
    return null;
  }
}

async function tryGoogleChirp3HD(
  text: string,
  role: VoiceRoleConfig,
  rate: number
): Promise<CachedAudio | null> {
  const apiKey = process.env.GOOGLE_TTS_API_KEY;
  if (!apiKey) return null;

  try {
    const res = await fetch(`https://texttospeech.googleapis.com/v1/text:synthesize?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        input: { text },
        voice: {
          languageCode: 'ko-KR',
          name: role.googleChirpVoice,
        },
        audioConfig: {
          audioEncoding: 'MP3',
          speakingRate: rate,
        },
      }),
    });

    if (!res.ok) return null;
    const data = (await res.json()) as { audioContent?: string };
    if (!data.audioContent) return null;
    const buffer = Buffer.from(data.audioContent, 'base64');
    recordProviderCall('Google Chirp 3 HD');
    return { buffer, contentType: 'audio/mpeg', provider: 'Google Chirp 3 HD' };
  } catch {
    return null;
  }
}

async function tryGeminiTTS(text: string, role: VoiceRoleConfig, mode: SpeechMode): Promise<CachedAudio | null> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return null;

  const ai = new GoogleGenAI({ apiKey });
  const instruction =
    mode === 'drama'
      ? `请用标准首尔韩国语、以${detectDramaEmotion(text)}自然朗读以下韩剧台词，保留口语停顿与连读，不要添加任何多余解释：${text}`
      : `请用标准首尔韩国语、清晰准确地朗读以下韩语学习内容，保留自然连读与收音，不要添加任何多余解释：${text}`;

  for (const modelName of ['gemini-2.5-flash-preview-tts', 'gemini-2.5-flash']) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: [{ parts: [{ text: instruction }] }],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: role.geminiVoice,
              },
            },
          },
        },
      });

      const inlineData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
      if (inlineData?.data) {
        const rawBuffer = Buffer.from(inlineData.data, 'base64');
        const wavBuffer = inlineData.mimeType?.includes('wav')
          ? rawBuffer
          : pcmToWav(rawBuffer, 24000, 1, 16);
        recordProviderCall(`Gemini (${modelName})`);
        return { buffer: wavBuffer, contentType: 'audio/wav', provider: `Gemini (${modelName})` };
      }
    } catch {
      // Try next model
    }
  }
  return null;
}

async function tryEdgeNeuralTTS(text: string, role: VoiceRoleConfig): Promise<CachedAudio | null> {
  try {
    const tts = new MsEdgeTTS();
    await tts.setMetadata(role.azureVoice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
    const { audioStream } = tts.toStream(text);

    const chunks: Buffer[] = [];
    await new Promise<void>((resolve, reject) => {
      audioStream.on('data', (chunk: Buffer) => chunks.push(chunk));
      audioStream.on('end', () => resolve());
      audioStream.on('error', (err: Error) => reject(err));
    });

    const buffer = Buffer.concat(chunks);
    if (buffer.length === 0) return null;
    recordProviderCall(`Edge Neural (${role.azureVoice})`);
    return { buffer, contentType: 'audio/mpeg', provider: `Edge Neural (${role.azureVoice})` };
  } catch {
    return null;
  }
}

async function tryPublicKoreanTTS(text: string): Promise<CachedAudio | null> {
  try {
    const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(
      text
    )}&tl=ko&client=tw-ob`;
    const res = await fetch(ttsUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });
    if (!res.ok) return null;
    const buffer = Buffer.from(await res.arrayBuffer());
    recordProviderCall('Seoul Korean Standard TTS');
    return { buffer, contentType: 'audio/mpeg', provider: 'Seoul Korean Standard TTS' };
  } catch {
    return null;
  }
}

export async function synthesizeKoreanSpeech(params: {
  text: string;
  roleId?: VoiceRoleId;
  mode?: SpeechMode;
  rate?: number;
}): Promise<CachedAudio | null> {
  const cleanText = params.text.trim();
  const roleId: VoiceRoleId = params.roleId && VOICE_ROLES[params.roleId] ? params.roleId : 'female_a';
  const mode: SpeechMode = params.mode === 'drama' ? 'drama' : 'standard';
  const rate = typeof params.rate === 'number' ? params.rate : mode === 'drama' ? 1.0 : 0.9;

  stats.totalRequests += 1;

  const cacheKey = `${roleId}:${mode}:${rate}:${cleanText}`;
  const cached = audioCache.get(cacheKey);
  if (cached) {
    stats.cacheHits += 1;
    return cached;
  }

  const role = VOICE_ROLES[roleId];

  const result =
    (await tryElevenLabs(cleanText, role, mode)) ||
    (await tryAzureSpeech(cleanText, role, mode, rate)) ||
    (await tryGoogleChirp3HD(cleanText, role, rate)) ||
    (await tryGeminiTTS(cleanText, role, mode)) ||
    (await tryEdgeNeuralTTS(cleanText, role)) ||
    (await tryPublicKoreanTTS(cleanText));

  if (result) {
    if (audioCache.size > 500) {
      const firstKey = audioCache.keys().next().value;
      if (firstKey) audioCache.delete(firstKey);
    }
    audioCache.set(cacheKey, result);
  }

  return result;
}

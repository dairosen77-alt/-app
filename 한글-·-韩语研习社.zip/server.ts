import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { synthesizeKoreanSpeech, getTTSStats, VOICE_ROLES, VoiceRoleId, SpeechMode } from './server/ttsService.js';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.post('/api/translate', async (req, res) => {
    try {
      const { text, direction } = req.body as {
        text?: string;
        direction?: 'ko-to-zh' | 'zh-to-ko';
      };

      if (!text || !text.trim()) {
        return res.status(400).json({ error: '请输入需要翻译的内容' });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        return res.status(500).json({ error: '服务器未配置 GEMINI_API_KEY' });
      }

      const ai = new GoogleGenAI({ apiKey });
      const isKoToZh = direction === 'ko-to-zh';

      const prompt = isKoToZh
        ? `请将以下韩语自然地翻译成中文，并提供该韩语句子的罗马音标注以及1-2个核心词汇或语法点解析（用中文简明说明）：\n\n${text.trim()}`
        : `请将以下中文自然地翻译成地道、礼貌的韩语（敬语体），并提供韩语译文的罗马音标注以及1-2个核心词汇或语法点解析（用中文简明说明）：\n\n${text.trim()}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              translatedText: {
                type: Type.STRING,
                description: isKoToZh ? '中文翻译结果' : '韩语翻译结果',
              },
              romanization: {
                type: Type.STRING,
                description: '韩语句子的罗马音标注',
              },
              notes: {
                type: Type.STRING,
                description: '简明的核心词汇或语法点解析（中文）',
              },
            },
            required: ['translatedText', 'romanization', 'notes'],
          },
        },
      });

      const resultText = response.text;
      if (!resultText) {
        return res.status(500).json({ error: '翻译服务未返回结果' });
      }

      const parsed = JSON.parse(resultText);
      return res.json(parsed);
    } catch (err) {
      console.error('Translation error:', err);
      return res.status(500).json({ error: '翻译请求失败，请稍后重试' });
    }
  });

  app.post('/api/tts', async (req, res) => {
    try {
      const { text, roleId, gender, mode, rate } = req.body as {
        text?: string;
        roleId?: VoiceRoleId;
        gender?: 'male' | 'female';
        mode?: SpeechMode;
        rate?: number;
      };

      const cleanText = text?.trim();
      if (!cleanText) {
        return res.status(400).json({ error: '缺少朗读文本' });
      }

      const resolvedRole: VoiceRoleId =
        roleId && VOICE_ROLES[roleId]
          ? roleId
          : gender === 'male'
          ? 'male_a'
          : 'female_a';

      const result = await synthesizeKoreanSpeech({
        text: cleanText,
        roleId: resolvedRole,
        mode: mode || 'standard',
        rate: typeof rate === 'number' ? rate : 0.95,
      });

      if (!result) {
        return res.status(502).json({ fallback: true, error: '语音合成服务暂时不可用' });
      }

      res.setHeader('Content-Type', result.contentType);
      res.setHeader('X-TTS-Provider', result.provider);
      return res.send(result.buffer);
    } catch (err) {
      console.error('TTS error:', err);
      return res.status(500).json({ fallback: true, error: '语音合成失败' });
    }
  });

  app.get('/api/tts/stats', (_req, res) => {
    return res.json(getTTSStats());
  });

  app.post('/api/tts/batch', async (req, res) => {
    try {
      const { texts, roleId = 'female_a', mode = 'standard', rate = 0.9 } = req.body as {
        texts?: string[];
        roleId?: VoiceRoleId;
        mode?: SpeechMode;
        rate?: number;
      };

      if (!Array.isArray(texts) || texts.length === 0) {
        return res.status(400).json({ error: '请提供需要预生成的文本列表' });
      }

      const batch = texts.slice(0, 20);
      let successCount = 0;
      for (const t of batch) {
        const r = await synthesizeKoreanSpeech({ text: t, roleId, mode, rate });
        if (r) successCount += 1;
      }

      return res.json({
        total: batch.length,
        successCount,
        stats: getTTSStats(),
      });
    } catch (err) {
      console.error('Batch TTS error:', err);
      return res.status(500).json({ error: '批量预生成失败' });
    }
  });

  app.get('/api/kdrama/search', async (req, res) => {
    try {
      const q = String(req.query.q || '').trim();
      if (!q) {
        return res.json([]);
      }
      const apiRes = await fetch(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(q)}`);
      if (!apiRes.ok) {
        return res.json([]);
      }
      const data = (await apiRes.json()) as Array<{
        show: {
          id: number;
          name: string;
          language?: string;
          premiered?: string;
          genres?: string[];
          officialSite?: string;
          url?: string;
          image?: { medium?: string };
          summary?: string;
        };
      }>;

      const results = data.slice(0, 8).map((item) => ({
        id: String(item.show.id),
        name: item.show.name,
        language: item.show.language || 'Korean',
        premiered: item.show.premiered || '',
        genres: item.show.genres || [],
        officialSite: item.show.officialSite || item.show.url || '',
        image: item.show.image?.medium || '',
        summary: (item.show.summary || '').replace(/<[^>]+>/g, '').slice(0, 120),
      }));

      return res.json(results);
    } catch {
      return res.json([]);
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
